setwd("G:/My Drive/R_Analyses/ListeningCV/DataPacket_Version1.0/Verification")

#### Step 1 - Reading and Merging Raw Data ####
setwd(".")

#packages
library(tidyverse)

#list of raw data files
files <- list.files(".\\RawData", pattern = "\\.txt")

#initialize dataframe
all <- data.frame()


#LOOP TO READ AND MERGE FILES#
setwd(".//RawData")

for(i in files){
     
     ##read data
     d<-read.delim(paste0(i), sep = "\t",header = F, skip =6)
     
     ##select columns
     d<-select(d,2,8, 14:15)
     
     #bind rows
     all <- rbind(all, d) 
}

#name columns
names<-c("sub", "event","acc","rt")
names(all) <- names


#write csv
setwd("..")
write.csv(all, file = ".//CleanedData/Ver_clean1.csv", row.names = F)

### Step 2 - Cleaning Data ####
#clear console and environment
cat("\014")
rm(list=ls())

#packages
library(tidyverse)

#read in raw data
d <- read.csv(".//CleanedData/Ver_clean1.csv", stringsAsFactors = F)

#keep only Test trials
d<- filter(d,grepl("^Test",event))

#code word vs nonword trials
d$plau<-ifelse(grepl("Non",d$event),"nonsense","sensible")


#code item no.

start <- regexpr("\\,\\s\\d+[_.]+", d$event) + 2
start
##we first find a patter with comma (\\,), then a space (\\s), then a digit appearing at least once. The start of what I need is two characters behind the comma (hence +2). In it below, I will take this and one more to get my item no. E.g. even name TestNonSense (23, 38_N.wav). See vocab analysis for another example

it <- as.integer(substring(d$event, start, start + 1))
it
d$item<-it

#add group info
d$group <- ifelse(d$sub>100 & d$sub<200, "bi",
                  "mono")


write.csv(d, file = ".//CleanedData/Ver_clean2.csv", row.names = F)

#### step 3 main analysis ####
#clear console and environment
cat("\014")
rm(list=ls())

d<- read.csv(".//CleanedData/Ver_clean2.csv",stringsAsFactors = F)

#identfy potential unsatisfactory items
d$score<-ifelse(d$acc =="C", 1, 0)

d_mono<-d[d$group=="mono",]

attach(d_mono)
which(tapply(score,item,mean)<0.75) 

# using NS data and acc scores <0.75 (words)
# bad items:15, 24, 27, 51, 52
detach(d_mono)

##removing all problematic items in the main dataframe
d<-d[d$item!="15"& d$item!="24"& d$item!="27"&
          d$item!="51"& d$item!="52"
     ,]

#reliability - accuracy
library(dplyr)
reliability<-d %>% dplyr::select("sub", "item", "score")

library(tidyr)
reliability_wide <- spread(reliability, item, score)
reliability_wide$sub<-NULL

psychometric::alpha(reliability_wide) #0.87


#RT analysis
d.rt<- d[d$score==1,]
d.rt<-d[d$plau=="sensible",]## Hits only

# add stimulus duration to compute offset rt
sti_info <- read.csv("ver_StiDur.csv", stringsAsFactors = F) ## bring in sti duration information

library(tidyverse)
d.rt<-left_join(d.rt,sti_info,by="item")

#compute offset rt
d.rt$rt.offset<-d.rt$rt-d.rt$duration

d.rt<-d.rt[d.rt$rt>149,]
d.rt<-d.rt[d.rt$rt.offset<4501,]

reliabilityRT<-d.rt %>% dplyr::select("sub", "item", "rt")

reliabilityRT_wide <- spread(reliabilityRT, item, rt)
reliabilityRT_wide$sub<-NULL

# Calculating total mean RT for reliability
rt_e <- rowMeans(reliabilityRT_wide[, c(TRUE, FALSE)], na.rm=T)  # with even items
rt_o <- rowMeans(reliabilityRT_wide[, c(FALSE, TRUE)], na.rm=T)  # with odd items

# Correlating RTs from even and odd items
r <- cor(rt_e, rt_o)
r #0.72

#add hit vs false alarm for scoring
detach(package:Rmisc)
detach(package:plyr)  
library(dplyr)

Hit<-data.frame(d[d$plau=="sensible",] %>% group_by(sub) %>% summarise(hit=sum(score)/29)) 

FA<-data.frame(d[d$plau=="nonsense",] %>% group_by(sub) %>% summarise(fa=1-(sum(score)/26))) 

HnF<-left_join(Hit,FA, by = "sub")

HnF$proacc <- HnF$hit - HnF$fa

##compute mean RT
ver_rt<-d.rt %>% group_by(sub) %>% summarise(prort = mean (rt))

##compute CV
ver_cv<-d.rt %>% group_by(sub) %>% summarise(procv = sd(rt)/mean (rt))

##join three data frames for final analysis
ver_final<-left_join(HnF,ver_cv, by = "sub", na.rm=T)
ver_final<-left_join(ver_final,ver_rt, by = "sub", na.rm=T)

ver_final$hit<-NULL
ver_final$fa<-NULL

write.csv(ver_final, file = ".//ver_final.csv", row.names = F)

###############
#clear console and environment
cat("\014")
rm(list=ls())

#compute RT-CV correaltions
ver_final<-read.csv("ver_final.csv")

library("Hmisc")

cor_1 <- rcorr(as.matrix(ver_final[,2:4])) #overall
cor_1 

ver_final$group <- ifelse(ver_final$sub>100 & ver_final$sub<200,
                            "bi",
                            "mono")

cor_2 <- rcorr(as.matrix(ver_final[ver_final$group=="mono",2:4])) #NS only
cor_2

cor_3 <- rcorr(as.matrix(ver_final[ver_final$group=="bi",2:4])) #NNS only
cor_3

#descriptives (Table 3)
##cv
library(Rmisc)
summarySE(data=ver_final,
          "procv",
          groupvars = "group",
          conf.interval = 0.95)

library(rcompanion)

groupwiseMean(procv~ group, 
              data   = ver_final, 
              conf   = 0.95, 
              digits = 3)

t.test(procv~group, data=ver_final)

library(Rmisc)
summarySE(data=ver_final,
          "procv",
          conf.interval = 0.95)

library(rcompanion)

groupwiseMean(procv~ 1, 
              data   = ver_final, 
              conf   = 0.95, 
              digits = 3)

##accuracy
library(Rmisc)
summarySE(data=ver_final,
          "proacc",
          groupvars = "group",
          conf.interval = 0.95)

library(rcompanion)

groupwiseMean(proacc~ group, 
              data   = ver_final, 
              conf   = 0.95, 
              digits = 3)

library(Rmisc)
summarySE(data=ver_final,
          "proacc",
          conf.interval = 0.95)

library(rcompanion)

groupwiseMean(proacc~ 1, 
              data   = ver_final, 
              conf   = 0.95, 
              digits = 3)
##rt
library(Rmisc)
summarySE(data=ver_final,
          "prort",
          groupvars = "group",
          conf.interval = 0.95)

library(rcompanion)

groupwiseMean(prort~ group, 
              data   = ver_final, 
              conf   = 0.95, 
              digits = 3)

library(Rmisc)
summarySE(data=ver_final,
          "prort",
          conf.interval = 0.95)

library(rcompanion)

groupwiseMean(prort~ 1, 
              data   = ver_final, 
              conf   = 0.95, 
              digits = 3)

