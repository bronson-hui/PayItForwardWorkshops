setwd("G:/My Drive/R_Analyses/ListeningCV/DataPacket_Version1.0/YesNo")

#### Step 1 - Reading and Merging Raw Data ####
setwd(".")

#packages

library(tidyverse)

#list of raw data files
files <- list.files(path = ".\\RawData", pattern = "\\.txt")

#initialize dataframe
all <- data.frame()

#LOOP TO READ AND MERGE FILES#
setwd(".//RawData")

for(i in files){
     
     ##read data
     d<-read.delim(paste0(i), sep = "\t",header = F, skip =6)
     
     ##select columns
     d<-select(d,2,8, 14:15)
     
     #bind rows
     all <- rbind(all, d) 
}

#name columns
names<-c("sub", "event","acc","rt")
names(all) <- names


#write csv
setwd("..")
write.csv(all, file = ".//CleanedData/YesNo_clean1.csv", row.names = F)

#### Step 2 - Cleaning Data ####
#clear console and environment
cat("\014")
rm(list=ls())

#packages
library(tidyverse)

#read in raw data 
d <- read.csv(".//CleanedData/YesNo_clean1.csv", stringsAsFactors = F)


#keep only Test trials
d<- filter(d,grepl("^Test",event))

#code word vs nonword trials
d$word<-ifelse(grepl("Non",d$event),"non","word")

#code the levels
#add key column for comp questions
d$level <- NA
d$level[grep("\\v4", d$event)]<- 4
d$level[grep("v5", d$event)]<- 5
d$level[grep("v3", d$event)]<- 3

##extract item no.
start <- regexpr("\\.\\d+[_.]+", d$event) + 1 ##find the pattern with a dot (\\.) then a digit appearing at least once (d+) then either _ or . at least once ([_.]+) in d$event. THEN, locate the start of this pattern (i.e., the dot (.), then the beginning of the extraction start one character after this (+1). Example event name: TestWords (11, v5.11_equality.wav) So, the item no. (i.e., 11) is one character behind the dot (beginning of start), and we take that one more (in it below); therefore 11. 

start

it <- substring(d$event, start, start + 1) ## in d$event, start with start, then take one more character. 
d$item1<-it

d$item2<-ifelse(d$word=="word","w",
                ifelse(d$word=="non","n",NA))

#combine word type, level and item no
d$item<- paste(d$item2,d$level,".", d$item1, sep="")
d$item[d$item == "n4.6."]<-"n4.16"
d$item1<-NULL
d$item2<-NULL

## remove column "event"
d$event<-NULL

#add group info
d$group <- ifelse(d$sub>100 & d$sub<200, "bi",
                  "mono")

d<-d[d$group=="bi"|d$group=="mono",]

d$score<-ifelse(d$acc=="C", 1,0)

write.csv(d, ".//CleanedData/YesNo_clean2.csv", row.names = F)

#### Step 3 main analysis ####
#clear console and environment
cat("\014")
rm(list=ls())

#read file from previous step
d<- read.csv(".//CleanedData/YesNo_clean2.csv",stringsAsFactors = F)

##ID bad items
mono<-d[d$group=="mono",]
attach(mono)
which(tapply(score,item,mean)<.75)
length(which(tapply(score,item,mean)<.75)) ##from NS data, id bad items which had accuracy lower than .75
detach(mono)

## exclude bad items 

d<-d[d$item!="n3.01" & 
          d$item!="n3.03" &
          d$item!="n3.04" &
          d$item!="n3.07" &
          d$item!="n3.16" &
          d$item!="n4.05" &
          d$item!="n4.09" &
          d$item!="n4.15" &
          d$item!="n4.16" &
          d$item!="n5.02" &
          d$item!="n5.05" &
          d$item!="n5.06" &
          d$item!="n5.11" &
          d$item!="n5.14" &
          d$item!="n5.18" &
          d$item!="w5.01",] 

#reliability - accuracy

reliability<-d %>% select("sub", "item", "score")

library(tidyr)
reliability_wide <- spread(reliability, item, score)
reliability_wide$sub<-NULL

## Calculating total score...
score_e <- rowMeans(reliability_wide[, c(TRUE, FALSE)])  # with even items
score_o <- rowMeans(reliability_wide[, c(FALSE, TRUE)])  # with odd items

## Correlating scores from even and odd items
r <- cor(score_e, score_o)
r #0.92

#RT analysis
d.rt<- d[d$score==1,]
d.rt<-d[d$word=="word",]## Hits only

# add stimulus duration to compute offset rt
sti_info <- read.csv("yesno_StiDur.csv", stringsAsFactors = F) ## bring in sti duration information

library(tidyverse)
d.rt<-left_join(d.rt,sti_info,by="item")

#compute offset rt
d.rt$rt.offset<-d.rt$rt-d.rt$duration

d.rt<-d.rt[d.rt$rt>149,]
d.rt<-d.rt[d.rt$rt.offset<2001,]

library(dplyr)
reliabilityRT<-d.rt %>% select("sub", "item", "rt")

library(tidyr)
reliabilityRT_wide <- spread(reliabilityRT, item, rt)
reliabilityRT_wide$sub<-NULL

# Calculating total mean RT for reliability
rt_e <- rowMeans(reliabilityRT_wide[, c(TRUE, FALSE)], na.rm=T)  # with even items
rt_o <- rowMeans(reliabilityRT_wide[, c(FALSE, TRUE)], na.rm=T)  # with odd items

# Correlating RTs from even and odd items
r <- cor(rt_e, rt_o)
r #0.92

#add hit vs false alarm for scoring
detach(package:Rmisc)
detach(package:plyr)  
library(dplyr)

Hit<-data.frame(d[d$word=="word",] %>% group_by(sub) %>% summarise(hit=sum(score)/119)) #proportion of Hits

FA<-data.frame(d[d$word=="non",] %>% group_by(sub) %>% summarise(fa=1-(sum(score)/45))) #proportion of False Alarm

HnF<-left_join(Hit,FA, by = "sub")

HnF$lexacc <- HnF$hit - HnF$fa

##compute mean RT
vocab_rt<-d.rt %>% group_by(sub) %>% summarise(lexrt = mean (rt))

##compute CV
vocab_cv<-d.rt %>% group_by(sub) %>% summarise(lexcv = sd(rt)/mean (rt))

##join three data frames for final analysis
vocab_final<-left_join(HnF,vocab_cv, by = "sub")
vocab_final<-left_join(vocab_final,vocab_rt, by = "sub")
vocab_final$hit<-NULL
vocab_final$fa<-NULL

write.csv(vocab_final, "yesno_final.csv", row.names = F)

##correlation

cat("\014")
rm(list=ls())

vocab_final<-read.csv("yesno_final.csv")

library("Hmisc")
cor_1 <- rcorr(as.matrix(vocab_final[,2:4])) #overall
cor_1

vocab_final$group <- ifelse(vocab_final$sub>100 & vocab_final$sub<200,
                            "bi",
                            "mono")

cor_2 <- rcorr(as.matrix(vocab_final[vocab_final$group=="mono",2:4])) #NS only 
cor_2

cor_3 <- rcorr(as.matrix(vocab_final[vocab_final$group=="bi",2:4]))  ##NNS only 
cor_3

#descriptives (Table 3)
##CV
library(Rmisc)
summarySE(data=vocab_final,
          "lexcv",
          groupvars = "group",
          conf.interval = 0.95)

library(rcompanion)

groupwiseMean(lexcv~ group, 
              data   = vocab_final, 
              conf   = 0.95, 
              digits = 3)

t.test(lexcv~group, data=vocab_final)

library(Rmisc)
summarySE(data=vocab_final,
          "lexcv",
          conf.interval = 0.95)

library(rcompanion)
groupwiseMean(lexcv~ 1, 
              data   = vocab_final, 
              conf   = 0.95, 
              digits = 3)


##accuracy
library(Rmisc)
summarySE(data=vocab_final,
          "lexacc",
          groupvars = "group",
          conf.interval = 0.95)

library(rcompanion)

groupwiseMean(lexacc~ group, 
              data   = vocab_final, 
              conf   = 0.95, 
              digits = 3)

library(Rmisc)
summarySE(data=vocab_final,
          "lexacc",
          conf.interval = 0.95)

library(rcompanion)
groupwiseMean(lexacc~ 1, 
              data   = vocab_final, 
              conf   = 0.95, 
              digits = 3)

##rt
library(Rmisc)
summarySE(data=vocab_final,
          "lexrt",
          groupvars = "group",
          conf.interval = 0.95)

library(rcompanion)

groupwiseMean(lexrt~ group, 
              data   = vocab_final, 
              conf   = 0.95, 
              digits = 3)

library(Rmisc)
summarySE(data=vocab_final,
          "lexrt",
          conf.interval = 0.95)

library(rcompanion)
groupwiseMean(lexrt~ 1, 
              data   = vocab_final, 
              conf   = 0.95, 
              digits = 3)

