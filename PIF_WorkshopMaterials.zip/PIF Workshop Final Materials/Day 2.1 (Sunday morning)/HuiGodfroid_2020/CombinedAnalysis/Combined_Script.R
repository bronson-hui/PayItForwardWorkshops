setwd("G:/My Drive/R_Analyses/ListeningCV/DataPacket_Version1.0/")

setwd(".")

#### Step 1 - Loading data sets from individual tasks ####
vocab<- read.csv(".\\YesNo/yesno_final.csv", stringsAsFactors = F)
con<-read.csv(".\\Construction/con_final.csv", stringsAsFactors = F)
ver<-read.csv(".\\Verification/ver_final.csv", stringsAsFactors = F)
listen<-read.csv(".\\Listening/listening_final.csv", stringsAsFactors = F)
listen<-dplyr::select(listen, 1, 43)

library(tidyverse)
overall<-left_join(vocab,con, by = "sub")
overall<-left_join(overall,ver, by = "sub")
overall<-left_join(overall,listen, by = "sub")
overall<-overall[overall$sub<200,] #filter NNS only
d<-overall

#write csv
write.csv(d, ".//CombinedAnalysis/combined_clean1.csv", row.names = F)


### Step 2 - Cleaning Data ####
#clear console and environment
cat("\014")
rm(list=ls())

d<- read.csv(".//CombinedAnalysis/combined_clean1.csv", stringsAsFactors = F)

###correlation matrix
PerformanceAnalytics::chart.Correlation(d[,2:11], histogram=TRUE, pch="160",cex.cor.scale=2, method = "spearman") ##inspect normality and correlation

#fix order of columns
d <- d[,c(1, 11, 2, 4, 3, 5, 7,6, 8,10,9)]
d

#screen task performance participants
d[19,"listenacc"]<-NA
d[35,c("lexacc", "lexrt","lexcv")]<-NA
d[29,c("proacc", "prort","procv")]<-NA

##check normality
apply(d, 2, shapiro.test) # apply shapiro.test to columns (2) in df d

#listenacc, synacc, and proacc were non-normal
# transform these three variables

d$listenacc<-log10(max(d$listenacc, na.rm=T)+0.1-d$listenacc)
d$synacc<-log10(max(d$synacc, na.rm=T)+0.1-d$synacc)
d$proacc<-log10(max(d$proacc, na.rm=T)+0.1-d$proacc)

###double check normality
apply(d, 2, shapiro.test) # apply shapiro.test to columns (2) in df d


cor_mat<-round(cor(d[,c(2:11)], method="spearman", use="pairwise.complete.obs"),2)
cor_mat

Hmisc::rcorr(as.matrix(d[,c(2:11)]), type = "spearman")


write.csv(cor_mat, ".//CombinedAnalysis/cor_mat.csv", row.names = T)

write.csv(d,".//CombinedAnalysis/combined_clean2.csv",row.names=F)


#### Step 3 Main analysis ####
#clear console and environment
cat("\014")
rm(list=ls())

d<-read.csv(".//CombinedAnalysis/combined_clean2.csv")

#### Regression Stage 1 ####
d$sub<-NULL
d<-data.frame(scale(d))
lm1a<-lm(listenacc~proacc+lexacc+synacc+procv+lexcv+lexrt+prort+synrt+syncv,data=d)
summary(lm1a)

lm1b<-update(lm1a, . ~ . -lexcv)
summary(lm1b)

lm1c<-update(lm1b, . ~ . -prort)
summary(lm1c)

lm1e<-update(lm1c, . ~ . -synacc)
summary(lm1e)

lm1f<-update(lm1e, . ~ . -syncv) #Final Model
summary(lm1f)

lm1g<-update(lm1f, . ~ . -synrt)
summary(lm1g)

lm1h<-update(lm1g, . ~ . -procv)
summary(lm1h)

lm1i<-update(lm1h, . ~ . -lexacc)
summary(lm1i)

d.1=d[abs(scale(resid(lm1f))) < 2.5,]
Final.Model.1<-lm(listenacc~proacc+lexacc+procv+lexrt+synrt,data=d.1)
summary(Final.Model.1)

#assumption checks
mean(Final.Model.1$residuals) #should be close to zero
plot(Final.Model.1) #random pattern in residuls and fitted-value plot
library(gvlma)
gvmodel <- gvlma(Final.Model.1) 
summary(gvmodel)

car::vif(Final.Model.1) #<10
car::durbinWatsonTest(Final.Model.1) ## should be within 1-3 (Field)
which(cooks.distance(Final.Model.1)>1) # <1
sjstats::std_beta(Final.Model.2, ci.lvl = 0.95)
relaimpo::calc.relimp(Final.Model.1)  #square lmg = sr^2 (Larson-Hall, p.409)

##validation
# Bootstrap mean and 95% CI for co-efficients
Final.Model.1v<-rms::ols(listenacc~proacc+lexacc+procv+lexrt+synrt,data=d.1, x=TRUE, y=TRUE)

Final.Model.1v

rms::validate(Final.Model.1v, method="boot", B=3000)

#### Regression Stage 2 ####

lm2a<-lm(proacc~lexacc+synacc+lexcv+lexrt+synrt, data=d)
summary(lm2a)

lm2b<-update(lm2a,.~.-synrt)
summary(lm2b) 

lm2c<-update(lm2b,.~.-lexcv)
summary(lm2c) ## final model

lm2d<-update(lm2c,.~.-synacc)
summary(lm2d)

d.2=d[abs(scale(resid(lm2c))) < 2.5,]

Final.Model.2<-lm(proacc~lexacc+synacc+lexrt,data=d.2)
summary(Final.Model.2)

#assumption checks
mean(Final.Model.2$residuals) #should be close to zero
plot(Final.Model.2) #random pattern in residuls and fitted-value plot
library(gvlma)
gvmodel2 <- gvlma(Final.Model.2) 
summary(gvmodel2)

car::vif(Final.Model.2) #<10
car::durbinWatsonTest(Final.Model.2) ## should be within 1-3 (Field)
which(cooks.distance(Final.Model.2)>1) # <1
sjstats::std_beta(Final.Model.2, ci.lvl = 0.95)
relaimpo::calc.relimp(Final.Model.2) #square lmg = sr^2 (Larson-Hall, p.409)


Final.Model.2v<-rms::ols(proacc~lexacc+synacc+lexrt,data=d.2, x=TRUE, y=TRUE)
rms::validate(Final.Model.2v, method="boot", B=3000)

#### Mediation analysis ####

d<-dplyr::select(d,1:3,8)
d<-d[complete.cases(d), ]
library(psych)
Final.Model.3<-psych::mediate (listenacc~ lexacc+lexrt +(proacc),std = TRUE, plot=T,n.iter = 3000, alpha=.05,data=d)
summary(Final.Model.3, digits=5)


rm(d,d.1,d.2)
save.image(file = ".\\CombinedAnalysis/CombinedAnalysis.RData")

