# clear the environment
rm(list = ls())
cat("\014")

getwd()

# setwd("C:/Users/Hui/Desktop/PIF_Day2_AM/Wrangling_Examples"")

# Example ----
## what is the goal?
?t.test()

# myresult <- t.test (A, B, data = d)

## What doI have?
d <- read.csv ("Offline_tests.csv")
View(d)

## Step 1 - keep only three columns
library(dplyr) # need to install?
library(tidyr)

?select()

d <- d %>% select (1:3)


## Step 2 - Turn it (long to wide)
d <- d %>% pivot_wider(id_cols = Participant, 
                       names_from = Group,
                       values_from = ReadingScores)

ttest_wide <- t.test(d$Bi, d$Mono)
ttest_wide

## Bonus: turn it back

d <- d %>% pivot_longer(cols =c("Bi","Mono"), 
                        names_to = "Group", 
                        values_to = "ReadingScores", 
                        values_drop_na = TRUE)

ttest_long <- t.test(ReadingScores ~ Group, data=d)
ttest_long

# chain the pipes up ----
## clear the environment
rm(list = ls())
cat("\014")

d <- read.csv ("Offline_tests.csv")

d <- d %>% select (1:3) %>% pivot_wider(id_cols = Participant, names_from = Group, values_from = ReadingScores)

# some vocab learning ----
## Clear the environment
rm(list = ls())
cat("\014")

## filter ( )
d <- read.csv ("Offline_tests.csv")
d <- d %>% filter (Participant > 20) # to filter means to keep, here we keep rows where participant has an id > 20

d <- read.csv ("Offline_tests.csv")
d <- d %>% filter (Participant > 20 & Group =="Mono") # two criteria using &

d <- read.csv ("Offline_tests.csv")
d <- d %>% filter (Participant > 20 | Group =="Mono") # either criterion using | (or)


## rename ( ) and rename_with
d <- read.csv ("Offline_tests.csv")
d <- d %>% select (1, 22) %>% rename (nativelanguage = L1) # rename takes NewName = OldName as the argument

d <- read.csv ("Offline_tests.csv")
d <- d %>% rename_with(tolower) %>% rename_with(toupper) # change columns to lower case then upper case

## group_by () %>% summarize () 
d <- read.csv ("Offline_tests.csv")
d <- d %>% 
        select (1, 2, 16) %>% 
        group_by(Group) %>% 
        summarise(meanTOEFL = mean(TOEFL, na.rm = T)) # group rows by Group, then summarize the mean (ignoring NAs)

## mutate () 
d <- read.csv ("Offline_tests.csv")
d <- d %>% 
        select (1, 2, 16, 24) %>% 
        group_by(Group, Intention) %>% 
        mutate (meanTOEFL = mean(TOEFL, na.rm = T))  # mutate a new column called meanTOEFL 
                                                    # compute the average of mean for TOEFL scores (by group and intention)

d <- read.csv ("Offline_tests.csv")
d <- d %>% 
      select (1, 9:12) %>% 
      mutate (Self_All = (SelfReading + SelfWriting + SelfListening + SelfSpeaking)/4) # mutate a new column called Self_All 
                                                                                       # compute the average of self ratings of the 4 skills 

## if_else ( )
d <- read.csv ("Offline_tests.csv")
d <- d %>% mutate(AgeGroup = if_else(Age > 27, "Old", "Young")) # mutate a new column called AgeGroup
                                                                # if age is > 27, we call the person "Old", or else "Young"
