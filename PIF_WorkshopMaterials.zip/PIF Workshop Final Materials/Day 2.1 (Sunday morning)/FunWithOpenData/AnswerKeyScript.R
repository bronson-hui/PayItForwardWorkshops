library(dplyr)
library(tidyr)

# T1
d<- read.csv ("YesNo_clean2.csv")

d <- d %>% filter(group == "mono") %>% group_by(item) %>% summarise(meanScore = mean(score)) %>% arrange(meanScore)
  

# T2        

d<- read.csv ("YesNo_clean2.csv")

d <- d %>% filter (item != "w5.01" &
                    item != "n5.02" &
                     item != "n5.06" & 
                      item != "n3.03" & 
                        item != "n3.01") %>%
      filter(group == "bi") %>%
      group_by(sub) %>% 
      summarise(meanScore = mean(score)) %>% 
      arrange(meanScore)

# T3        

d<- read.csv ("YesNo_clean2.csv")

d_word <- d %>% filter (word == "word") %>% 
                filter (item != "w5.01") %>%
                filter(group == "bi") %>%
                group_by(sub) %>% 
                summarize(Hit = mean(score))

d_non <- d %>% filter (word == "non") %>% 
   filter (item != "n5.02" &
            item != "n5.06" & 
              item != "n3.03" & 
               item != "n3.01") %>%
  filter(group == "bi") %>%
  group_by(sub) %>% 
  summarize(FalseAlarm = 1-(mean(score)))


d_final <- left_join(d_word, d_non, by = "sub") %>% mutate (HitMinusFA = Hit - FalseAlarm)

View(d_final)

