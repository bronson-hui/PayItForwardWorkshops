########################################
##############LLT 873 DEMO##############
#############Graphing ##################
########################################

rm(list = ls(all.names = TRUE)) # clear the enironment

# Set up your working directory
getwd() # "/Volumes/GoogleDrive/My Drive/PIF workshop materials (tentative)/Day2.2_Visualizations"
setwd("/Volumes/GoogleDrive/My Drive/PIF workshop materials (tentative)/Day2.2_Visualizations")

d1<- read.csv('vocabulary.csv', header = T)

# Data examination
head(d1)
summary(d1)

library(ggplot2)

##one continuous variable (Boxplot) 
# Why should we use boxplots over bar graphs: Check out Larson-Hall (2017) 
class(d1$vocabulary)
d1$vocabulary <- as.numeric(d1$vocabulary) # in case vocabulary is not read as a numeric variable

p1<-ggplot(data=d1, aes(y=vocabulary)) ##Step 1: groundwork
p1

p1+
  geom_boxplot() ##Step 2: choose the right plot


p1+
  geom_boxplot() +
  theme(axis.title.x=element_blank(), 
        axis.text.x=element_blank(), 
        axis.ticks.x=element_blank()) + ## Step 3: remove info in x-axis 
  labs(y = "Vocabulary Scores") ## Change the y-axis label


##two continuous variables (Scatter plot)
class(d1$year) # check the type of the variable, year

p2<-ggplot(data=d1, aes(x=education, y=vocabulary)) ##Step 1: groundwork (makes more sense to plot education on the x-axis)
p2

p2+
  geom_point()   ##Step 2: choose the right plot


p2+
  geom_point() +
  geom_smooth(method=lm, se=TRUE, level=0.95) ## Step 3a: add regression line and 95% CI
?geom_smooth()


p2+
  geom_point() +
  geom_smooth(method=lm, se=TRUE, level=0.95) + 
  scale_y_continuous(name="Vocabuary Size", breaks=seq(0,10,2), limits=c(0,10))+ ## Step 3b: manipulate breaks and scales ###for y: breaks = seq(0,20,2) <- from 0 to 20, one break in every 2 units
  scale_x_continuous(name="Years of Education", breaks=seq(0,20,2), limits=c(0,20))  ###for x: breaks = seq(0,20,2) <- from 0 to 20, one break in every 2 units
  #labs(x = 'Years of Education', y = "Vocabulary Size")
  

##two coninuous plus one factor (use of color)

p3<-ggplot(data=d1, aes(x=education, y=vocabulary, color=sex)) ##Step 1: groundwork + color
p3

p3+
  geom_point()   ##Step 2: choose the right plot


p3+
  geom_point() +
  geom_smooth(method=lm, se=TRUE, level=0.95) ## Step 3a: add regression line 


p3+
  geom_point() +
  geom_smooth(method=lm, se=TRUE, level=0.95) + 
  scale_y_continuous(name="Vocabuary Size",breaks=seq(0,10,2), limits=c(0,10))+ ## Step 3b: manipulate breaks and scales ###for y: breaks = seq(0,20,2) <- from 0 to 20, one break in every 2 units
  scale_x_continuous(name="Years of Education",breaks=seq(0,20,2), limits=c(0,20)) ###for x: breaks = seq(0,20,2) <- from 0 to 20, one break in every 2 units
  

##two coninuous plus one factor (use of facet)

p4<-ggplot(data=d1, aes(x=education, y=vocabulary))+facet_grid(.~sex) ##Step 1: groundwork
p4

p4+
  geom_point()   ##Step 2: choose the right plot


p4+
  geom_point() +
  geom_smooth(method=lm, se=TRUE, level=0.95) ## Step 3a: add regression line 


p4+
  geom_point() +
  geom_smooth(method=lm, se=TRUE, level=0.95) + 
  scale_y_continuous(name="Vocabuary Size", breaks=seq(0,10,2), limits=c(0,10))+ ## Step 3b: manipulate breaks and scales###for y: breaks = seq(0,20,2) <- from 0 to 20, one break in every 2 units
  scale_x_continuous(name="Years of Education", breaks=seq(0,20,2),limits=c(0,20)) ###for x: breaks = seq(0,20,2) <- from 0 to 20, one break in every 2 units

##one continuous by one factor (boxplot)

p5<-ggplot(data=d1, aes(x=sex, y=vocabulary)) ##Step 1: groundwork
p5

p5+
  geom_boxplot() +  ##Step 2a: choose the right plot (boxplot)
  geom_dotplot(binwidth = 0.1, binaxis = "y", dotsize = 2, stackdir='center')+ ##Step 2b: add dots
  scale_y_continuous(name="Vocabuary Size", breaks=seq(0,10,2), limits=c(0,10))+ ##Step 3a: fix y-axis
  scale_x_discrete(name="Sex") ##Step 3b: fix x-axis


##one continuous by one factor (line graph)

p6<-ggplot(data=d1, aes(x=sex, y=vocabulary)) ##Step 1: groundwork
p6

p6+
  stat_summary(fun = mean, 
               geom = "point") + ## Step 2a: add the mean as a point
  stat_summary(fun = mean, geom = "line", aes(group = "sex")) + ##Step2b: add the line between groups
  stat_summary(fun.data = mean_cl_boot, geom = "errorbar", aes(width = .3)) + ##Step 2c: add error bars 
  scale_y_continuous(name="Vocabuary Size", breaks=seq(0,10,2), limits=c(0,10))+ ##Step 3a: fix y-axis
  scale_x_discrete(name="Sex") ##Step 3b: fix x-axis
  

##one continuous by two factors (boxplot)
d1$agegp<-ifelse(d1$year<1995, "old", "young") ##creat another factor 

####start plotting

p7<-ggplot(data=d1, aes(x=sex, y=vocabulary, color=agegp)) ##Step 1: groundwork
p7

p7+
  geom_boxplot() +  ##Step 2a: choose the right plot (boxplot)
  geom_dotplot(binwidth = 0.1, binaxis = "y", dotsize = 2, stackdir = "center", position = "dodge")+ ##Step 2b: add dots
  scale_y_continuous(name="Vocabuary Size", breaks=seq(0,10,2), limits=c(0,10))+ ##Step 3a: fix y-axis
  scale_x_discrete(name="Sex") + ##Step 3b: fix x-axis
  scale_color_discrete(name="Age Groups", labels=c("Old", "Young")) ## Step 3c: fix legend

# a good example to show you:
# 1) why it is important to explore your data using graphs
# 2) how to make your graphs look nice

### Let's try a larger data set
## Data: Reading and writing data
rw <- read.csv("readwrite2.csv")
# reading score, writing score, group (level)
head(rw)
summary(rw)
table(rw$level) # get the number of participants for each group

# visualize (any) correlation between reading and writing scores
ggplot(rw, aes(x = reading, y = writing)) + 
  geom_point() 

ggplot(rw, aes(x = reading, y = writing)) + 
  geom_point(position = position_jitter()) # using positions_jitter() to avoid overplotting (compare this graph to the previous one)

ggplot(rw, aes(x = reading, y = writing)) + 
  geom_point(position = position_jitter()) + 
  stat_smooth() # add a regression line (see the relationship between students' reading & writing scores)

# add proficiency level to the aesthetics
ggplot(rw, aes(x = reading, y = writing, color = level)) + # note that level is read as a numberic variable
  geom_point(position = position_jitter())

# Change the level variable to factor and provide labels
rw$level <- factor(rw$level, 
                   labels = c("Novice", "Low-IM", "High-IM", "Advanced", "Superior"))

ggplot(rw, aes(x = reading, y = writing, color = level)) + # compare the graph to the one created earlier
  geom_point(position = position_jitter())

ggplot(rw, aes(x = reading, y = writing, color = level)) + 
  geom_point(position = position_jitter(), alpha = 0.3) + # alpha: adjust the transparency level of your data points (0: transparent; 1: opacue)
  stat_smooth(method = "lm") # this will fit a line for each group because we have specified group (level)

# to fit a line for overall data but still keep the group colors, move the color aesthetic to lower level function
ggplot(rw, aes(x = reading, y = writing)) + 
  geom_point(aes(color = level), position = position_jitter(), alpha = .3) + 
  stat_smooth(method = "lm")
# notice Simpson's paradox here: a trend appears in several groups of data but disappears or reverses when the groups are combined

## Color scale
ggplot(rw, aes(x = reading, y = writing, color = level)) + 
  geom_point(position = position_jitter(), alpha = .3, size = 1) + 
  stat_smooth(method = "lm") + 
  scale_color_viridis_d() # Use the color scale to make plots that are pretty, better represent your data, easier to read by those with colorblindness

ggplot(rw, aes(x = reading, y = writing, color = level)) + 
  geom_point(position = position_jitter(), alpha = .3, size = 1) + 
  stat_smooth(method = "lm") + 
  scale_color_brewer(palette = "Set1")

## Axis scale
ggplot(rw, aes(x = reading, y = writing, color = level)) + 
  geom_point(position = position_jitter(), alpha = .3, size = 2) + 
  stat_smooth(method = "lm", se = FALSE) + 
  scale_color_viridis_d() + 
  scale_x_continuous(limits = c(0, 30)) + 
  scale_y_continuous(limits = c(0, 30)) 

# Use coordinate that applies 1:1 scale
ggplot(rw, aes(x = reading, y = writing, color = level)) + 
  geom_point(position = position_jitter(), alpha = .3, size = 2) + 
  stat_smooth(method = "lm", se = FALSE) + 
  scale_color_viridis_d() + 
  scale_x_continuous(limits = c(0, 30)) + 
  scale_y_continuous(limits = c(0, 30)) + 
  coord_equal()

# Final, polished version:
ggplot(rw, aes(x = reading, y = writing, color = level)) + 
  geom_point(aes(color = level), position = position_jitter(), 
             alpha = .3, size = 2) + 
  stat_smooth(method = "lm", se = FALSE) + 
  scale_color_viridis_d() + 
  scale_x_continuous(limits = c(0, 30)) + 
  scale_y_continuous(limits = c(0, 30)) + 
  coord_equal() +
  labs(x = "\nReading score", # \n: add a new line
       y = "Writing score\n", 
       title = "Relationship between reading and \nwritings scores by proficiency level", 
       color = "Proficiency level") + 
  theme_bw() # The classic dark-on-light ggplot2 theme. A theme with only black lines of various widths on white backgrounds

### save
ggsave("correlation.png", width = 6, height = 5)

### Extra
# Facet: Create subplots
ggplot(rw, aes(x = reading, y = writing)) + 
  geom_point(position = position_jitter(), alpha = .1) + 
  stat_smooth(method = "lm") + 
  coord_equal() + 
  facet_wrap(. ~ level, nrow = 1) + 
  labs(title = "Relationship between reading and writings scores by proficiency level", 
       x = "\nReading score", 
       y = "Writing score\n") + 
  theme_bw()

library(languageR)
data <- lexdec
set.seed(111)
d1 <- data[sample(nrow(data), 100),]
write.csv(d1, 'lexdecision.csv', row.names = F)
