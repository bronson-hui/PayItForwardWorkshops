#---------------------------------------------------------#
# ---------- Pay It Forward Workshop - 2021 --------------#
#---------------------------------------------------------#
# ----------------Day 1.1 - Basics in R ------------------#
#---------------------------------------------------------#


### 1a. Basics in R: Understanding the RStudio Layout  #####

# Welcome to your first script in R!

# Note that the hashtag symbol is used to let me type comments. I can type comments on their own line, or to the right of the code.

# You can run code by putting your cursor on the line you wish to run, then clicking on "Run" in the upper right hand corner of the "Source" pane (this one)
install.packages("gapminder") # Install the package

# Load the package
library(gapminder)
# Note that the code you have JUST RUN appears in the "Console" pane below

##### Explore the data set:

# What is this data set we're working with?
viewdata <- data.frame(gapminder)

# Now, double click on the object "viewdata" you've created in your global environment pane (upper right)

# The "Console" pane will also show you the output of functions
# Use the function "names" to print the names of the variables in the data set
names(gapminder)
# See the output BELOW in your console?

# Statistical overview:
# Use the function "summary" to get a statistical overview of the dataset
summary(gapminder)
     # "Year" indicates that the years for this data set run from 1952 to 2007
     # "Country" indicates the number of observations for each country - looks each country was sample 12 times
     # "lifeExp", "pop", and "gdpPercap" are where the descriptive statistics become informative for us

# Create a basic plot:
plot(lifeExp ~ year, gapminder) # Look what popped up in your "everything else" pane!
plot(lifeExp ~ gdpPercap, gapminder)
# Code syntax for the "plot" function:
        # plot(variable 1 ~ variable 2, dataset)


# Clear the environment by clicking on the little broom in the three non-Source panes (Console, Global Environment, Plots)

## 1b. Basics in R: Working with objects, functions, and arguments ####

# Math with R
5 + 10 + 15
# Note that the output appears in the console pane below

#### Objects
# Let's create some objects!
# the left-facing arrow is the all-powerful ASSIGNMENT OPERATOR!
# The line of code below can be read as "create an object a, and assign to it the value of 5"
a <- 2
b <- 4
c <- 6
# As you ran the three lines of code above, what did you notice?

# These objects store the data you've told it to
# Go ahead and run the three lines of code below, and you'll see that RStudio prints out what each object contains
a
b
c

# Note that R is picky about CAPITALIZATION - what happens when you run the line of code below?
A

# We can manipulate objects
# Below is the equivalent of the first math problem we did above
my_weekly_coffee_bill <- a + b + c
#    Now my sum is stored as an object

# To see the sum, you can just run the name of the object
my_weekly_coffee_bill
#    Looks like I should start bringing in my own coffee to save some money...

#### VECTORS
# A vector is basically a list of values
# The code below says: "create an object titled my_weekly_happy_hour_bill and assign to it the collection of values 10, 15, and 20"
my_weekly_happy_hour_bill <- c(10, 15, 20) #vector
# Note what this vector looks like in the "Global Environment" pane (upper right). 
# How does it differ from the coffee bill object we created ?

# How much money do I waste per week on happy hour, on average?
# Let's apply the "mean" function to this vector!
mean(my_weekly_happy_hour_bill)

# We've been working with objects that represent numbers, but objects can be other types of data as well

# Working with text data (a.k.a. "character strings")
husband <- "Paul" 
# note that character strings must be placed in quotes, or else R will think they're supposed to be something like (like an OBJECT!)
brother <-  "Ben"
dog <- "Bernie"

# We can combine the text objects we created into vectors
family_objects <- c(husband, brother, dog)
family_objects # print the output

# We can also combine text directly into vectors
family_text <- c("Paul", "Ben", "Bernie")
family_text # print the output

# For the two vectors we created above (family_objects and family_text):
        # What is the difference between their inputs (a.k.a. how you made them in the Source pane)?
        # Between their output (a.k.a. what they print out in the Console pane)?
        # Between how they're stored (a.k.a. in the Global Environment pane)?

# Note that R keeps track of the different types of data you have
# In the Global Environment pane (upper left), how does R describe the 3 vectors you created above?
# "chr" vs. "num"

# What happens if we apply the "mean" function (the same function we did above to find out how much money I'm throwing away on frivolous entertainment) to a character vector?
 mean(family_text)




### 2. Setting the Working Directory ##################

# What the heck is a working directory?
        # the file path (telling R where to go to find the files)
        # you'll use this to tell R to get scripts, data sets, etc. as well as to tell R where to store things you create
 
# The function "getwd" below asks R to tell you what file it is currently pulling from
getwd()
 # When you run the code above, it should tell you the file path for where you stored this R script!
# WD notes
        # Your wd is automatically set to wherever your RScript is stored
        # This can be overwritten if you want to keep your files organized:
                # Set your working directory
                # Click on the "Session" tab -> Set Working Directory -> Choose Directory

### 3. Installing packages ##################

# What the hell are packages?!?
     # ~ add-ons (like in the Chrome browser)
     # benefits of working with open-source software
     # contain: functions, code, sample data, documentation

# Here is a silly example to get us started:
# Use the function "install.packages" to install the package named "praise"
install.packages("praise")

# Use the function "library" to load the package named "praise"
library(praise)
#    The function "library" calls the package into our workspace (sort of like a librarian grabbing a book off of the shelf and bringing it to you!)

# Let's run the "praise" function (note that it's the same color as the functions above!) taken from the "praise" package, and see what happens
praise()

# Now run it again
praise()
# And again
praise()
# And again
praise()
# Maybe you're getting tired of moving your mouse to click on "run" above? Not worth  the excessive praise??
     # Consider using the keyboard shortcut to run, which is:
     # On a Mac: option + return 
     # On a PC:  alt + enter
     # See: https://support.rstudio.com/hc/en-us/articles/200711853-Keyboard-Shortcuts

# You can also load packages manually!
     # Click on the "Packages" tab in the "Everything Else" pane (lower right)
     # You'll see a list of packages organized alphabetically
     # A "check" indicates you have that loaded it (see that "base" is loaded for you!)
     # Click on "Install" and search for "ggplot2", then click "install"
     # Notice what happened in the console? The code for the "install.packages" function appeared below!



### 4. Importing and Exporting Data #####################################

rm(list = ls()) ##clear the global environment
# Notice that all the objected disappeared from the GE pane!
# This is a shortcut for clicking on the little broom icon
# You'll learn that most of the things we do via point-and-click in R can also be done with lines of code or with keyboard shortcuts

# Let's import some data!

# Data can be imported manually (point-and-click)
     # Click on the "Import Dataset" tab in the global environment pane (top right)
     # Check out all of the different types of files you could import!
     # Navigate to "Text (readr), and browse to find the file titled "toefl_study.csv"
     # You could click "Import", or... copy the code, paste it into the source pane (this one!) and run it! 

# Paste your code in the line(s) below ⭣⭣⭣⭣⭣⭣⭣⭣⭣⭣⭣⭣⭣⭣⭣
library(readr)
toefl_study <- read_csv("toefl_study.csv")
View(toefl_study)


# Now, HIGHLIGHT the three lines of code you pasted above ⭡⭡⭡⭡⭡⭡ and run it!

# We'll work on exporting later, let's dig into exploring the data itself for now

### 5. Data Types and Dataframes #####################################
str(toefl_study) ##check the structure of the data (i.e., what data types are we working with?)
     # Subject: integers (similar to the "num" type we saw earlier, don't worry about the difference for now)
     # L1: characters
     # TOEFL: integers

# Give a summary of all variables in the data frame "toefl_study"
summary(toefl_study) 
#    Note that R provides different data summaries for the different types of data!

# We can also ask for the summary of just one variable in the data frame
# We tell R to find this variable with the syntax "data$variable"
summary(toefl_study$Sub)

# However, we don't want R to do MATH with the subject ID# - we want F to treat that variable as a FACTOR (i.e. levels of CATEGORICAL data)

# Change the variable "Sub" to Factor (nominal) using the function "as.factor"
toefl_study$Sub <- as.factor(toefl_study$Sub)


# Now, when we re-run the same code, we can see that R identifies the numbers as levels of a categorical variable
summary(toefl_study$Sub)

# For YOU to code: how could we tell R to change the variable "gender" into FACTOR (i.e.a categorical variable)? 
# Write your code in the line(s) below, then run it ⭣⭣⭣⭣⭣⭣⭣⭣⭣⭣⭣⭣⭣⭣⭣




# The base R package we spotted earlier in the "Everything Else" pane (lower right) has a couple of handle built-in functions for exploring your data:
summary(toefl_study) # summarize the the whole dataframe - have we correctly told R to interpret "sub" and "gender" as factors?

mean(toefl_study$TOEFL) # find the mean of the variable "TOEFL"

sd(toefl_study$TOEFL) # find the SD of the variable "TOEFL"


# Resources to explore later: 
# See here for more basic data frame exploration examples: https://www.youtube.com/watch?v=gy1yhzbf_ko&list=PLGPGLQRuosDKwjTbOknj12ASPFpJ-V6vK&index=17

# See here for more data type and basic R math examples: https://www.youtube.com/watch?v=BC8b2M1cs0A&list=PLGPGLQRuosDKwjTbOknj12ASPFpJ-V6vK&index=3



# What the heck is a DATA FRAME?
     # Basically it refers to how R "reads" your data set into RStudio
     # R basically turns your data set into an object, which we call a data frame (df)
     # A data frame consists of a series of VECTORS (i.e. lists of data)
     # A data frame can contain multiple types of data, as we saw above (categorical, numeric, etc.)
     # see more here: https://www.statmethods.net/input/datatypes.html

# By storing the data as a data frame object in the Global Enviroment, we can further manipulate it in R...
# For example, let's say we're only interested in the FEMALES in this study (we'll assume that female == 1 and male == 2)
# We'll use the "subset" function to create a new data frame
toefl_female <- subset(toefl_study, Gender == 1)
# Syntax:
# new_dataframe <- subset(old_dataframe, variable == which subset we want)

# What if we want to SAVE this dataframe that we worked so hard to create?
# Inspect the code below - can you "translate" it into plain English?
write.csv(toefl_female , "toefl_female.csv")
# After running the line of code above, do you see it in your folder?

# Just as you can import different types of files, you can also export TO different types of files
# See here for more options: https://www.guru99.com/r-exporting-data.html


### 6. Practice Exercises #####################################
        # A. Open the SPSS datafile titled "DeKeyser2000.sav"

        # B. Click on the data frame "DeKeyser2000" in the global environment pane to open it up

# This data set comes from Robert DeKeyser's study "THE ROBUSTNESS OF CRITICAL PERIOD EFFECTS IN SECOND LANGUAGE ACQUISITION"
# His participants were 57 L1 Hungarian - L2 English speakers who all came to the United States at different ages (column AGE)
# 15 of the participants came to the US before the age of sixteen, and 42 came after the age of 16 (column Status)

        # C. Use the structure function (str) to inspect the data - what data types does R think the three columns of information are?

        # D. Use the summary function (summary) to get a basic statistical summary of the data

        # E. Status is supposed to be a FACTOR (i.e. a categorical variable0 indicating whether the participant is in the early or late arrivals group. Change it to a factor:

        # F. Create a new data frame that only looks at the late arrivals (Status == 2). Give it a meaningful name!

        # G. Save this new data frame as a .csv file. 

        # H. Save this new data frame as an SPSS file by executing the following two lines code. 
                # In the "write_sav" line, be sure to change the section "whatever_your_new_dataframe_is" to match the name of your data frame, and the "whatever you want to call it the file" section to something more meaningful
library(haven)
write_sav(whatever_your_new_dataframe_is, "whatever you want to call it the file.sav")

# Do you see your new .csv and .spss files in your folder?