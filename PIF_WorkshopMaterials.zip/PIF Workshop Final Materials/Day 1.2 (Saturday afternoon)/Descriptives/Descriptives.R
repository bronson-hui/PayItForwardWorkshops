# PIF Workshop on R ----
# Day 1 Afteroon
# Descriptives

#Clear the environment
rm(list = ls())
cat("\014")

#get and set working directory
getwd()
setwd("C:/Users/Hui/Desktop/PIF_Day1_PM/Descriptives")

# 1. create your own csv ---
# Open Excel
# Create three columns: sub (1-50), vocab (random no using the rand() function), group (randomly assign Ex & Cont)

# 2. read in your csv file ---
toy<-read.csv("toy.csv")
#toy<-read.csv("toy.csv", sep = ";") # for Europeans
summary(toy)
str(toy)

# toy$sub<-as.factor(toy$sub)
toy$sub<-as.numeric(toy$sub)
str(toy)

# 3. create school variable
toy$school<-ifelse(toy$sub<25,"SchA","SchB")
View(toy)

# 4. save it as a csv in working directory
write.csv(toy, file = "toy_with_sch.csv", row.names=FALSE)

# 5. Let's run some descriptives

rm(list = ls())
cat("\014")

# import your csv file and call it d
d <- read.csv ("toy_with_sch.csv")

# Overview
summary(d)
str(d)

# check and change data type
d$sub<- as.factor (d$sub)
d$school<- as.factor (d$school)
d$group<- as.factor (d$group)

# One categorical variable
summary(d$school)

# One numeric variable
library(Rmisc) ##install it if you haven't <- install.packages("Rmisc")
summarySE(data=d,
          "vocab",
          conf.interval = 0.95)

library(rcompanion) #need installation??
groupwiseMean(vocab ~ 1, #1 here in this line means there are no groups in your summary
              data   = d, 
              conf   = 0.95, 
              digits = 3)

psych::describe(d)


# One numeric by one factor
Rmisc::summarySE(data=d,
                 "vocab", 
                 groupvars = "school",
                 conf.interval = 0.95)

rcompanion::groupwiseMean(vocab ~ school, 
                          data = d, 
                          conf = 0.95, 
                          digits = 3)

psych::describeBy(d$vocab,d$school)

# One numeric by two factors
Rmisc::summarySE(data=d,
                 "vocab", 
                 groupvars = c("school","group"),
                 conf.interval = 0.95)

rcompanion::groupwiseMean(vocab ~ school + group, 
                          data = d, 
                          conf = 0.95, 
                          digits = 3)

psych::describeBy(d$vocab,list(d$school,d$group))

## let's do some simulation ----
rm(list = ls())
cat("\014")

# One group
set.seed(1) # set our random seed, so we can reproduce this
score <- rnorm(n=50, mean = 0, sd = 1) # use the rnorm () function to create a normal distribution
                                          # the function takes three arguments: n, mean, and sd        
summary(score)  #check what we have got

# Two groups (without group differences)
rm(list = ls())
cat("\014")

set.seed(1)
score <- rnorm(n=50, mean = 0, sd = 1)
group <- sample(x = c("A", "B"), size = 50, replace = T) # we use the sample ( ) function to create groups
                                                        # c represents the population; here we have two letters (A and B); the program will draw samples from these two letters
                                                        # size is like N (how many samples do you want?)

score
group

d <- data.frame (score, group) # combine the two vectors to form a dataframe
summary (d)

d$group <- as.factor (d$group)
summary(d)

Rmisc::summarySE(data=d,
                 "score", 
                 groupvars = "group",
                 conf.interval = 0.95)

rcompanion::groupwiseMean(score ~ group, 
                          data = d, 
                          conf = 0.95, 
                          digits = 3)


# Two groups (with difference)
rm(list = ls())
cat("\014")

set.seed(1)
score <- rnorm(n=100, mean = c(0, 1), sd = 1)
group <- rep(c("A", "B"), length.out = 100) # we use the sample ( ) function to create groups
                                                        # c represents the population; here we have two letters (A and B); the program will draw samples from these two letters
                                                        # size is like N (how many samples do you want?)
summary(score)
group

d <- data.frame (score, group) # combine the two vectors to form a dataframe
summary (d)

d$group <- as.factor (d$group)
summary(d)

Rmisc::summarySE(data=d,
                 "score", 
                 groupvars = "group",
                 conf.interval = 0.95)

rcompanion::groupwiseMean(score ~ group, 
                          data = d, 
                          conf = 0.95, 
                          digits = 3)
