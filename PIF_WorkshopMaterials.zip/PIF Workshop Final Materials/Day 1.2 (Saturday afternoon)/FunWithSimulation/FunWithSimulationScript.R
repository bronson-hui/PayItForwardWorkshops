# Complete the tasks below: ----

## clear the environment and console ----


## get and set your working directory ----


## Create data for vocabulary scores (mean = 12, sd = 6) for three groups (N = 75; group names: Control, Experiment1, and Experiment 2) with no mean differences ----

## Generate descriptives for these data

## Repeat the same procedure, but dial up the N to 750, what happens to the confidence intervals?



## Create data for vocabulary scores (mean = 12, sd = 6) for three groups (N = 75; group names: Control, Experiment1, and Experiment 2) 
    # with the two experimental groups outperforming the control group, but the two experimental groups show no differences 


## Generate descriptives for these data