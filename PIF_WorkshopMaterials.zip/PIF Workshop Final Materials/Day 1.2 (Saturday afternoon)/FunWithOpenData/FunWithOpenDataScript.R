# Complete the tasks below: ----

## clear the environment and console ----


## get and set your working directory ----


## Read in "Offline_tests.csv" and call it "d" ----

## Check (and make changes to) data types ----


## Answer the following questions:
### How many participants are in each of the two groups? 

### What are the mean and SD for reading scores for the whole sample?

### What about self-rated reading ability?

### Generate descritpives for self-rated reading ability by group

### Is there any difference in self-rated reading ability by group?

## What about FormTotal and Meaning? Did the two groups perform differently?

