##################################
#reliability of instruments
#Yingzhao Chen
#last updated: 5/13/2020
##################################

sessionInfo()

####load packages#### 
library(CTT)
library(here)
library(tidyr)
library(dplyr)
library(multicon)

####load data using here####
fr <- read.csv(here("Data", "Form_reliability.csv"))
mr <- read.csv(here("Data", "Meaning_reliability.csv"))
fpb.sd <- read.csv(here("Data", "Fpb_sd.csv"))
fpm.sd <- read.csv(here("Data","Fpm_sd.csv"))
fsb.sd <- read.csv(here("Data", "Fsb_sd.csv"))
fsm.sd <- read.csv(here("Data", "Fsm_sd.csv"))
spb.sd <- read.csv(here("Data", "Spb_sd.csv"))
spm.sd <- read.csv(here("Data", "Spm_sd.csv"))
ssb.sd <- read.csv(here("Data", "Ssb_sd.csv"))
ssm.sd <- read.csv(here("Data", "Ssm_sd.csv"))

####Reliability cronbach alpha for form recognition####

f <- itemAnalysis(fr[, 2:65],
                  itemReport = TRUE, NA.Delete = TRUE)
f

####Reliability for cronbach alpha meaning recognition####

m <- itemAnalysis(mr[, 2:33], 
                  itemReport = TRUE, NA.Delete = TRUE)
m


#####Reliability split half for LDTs####
#form priming
fp <- rbind(fpb.sd, fpm.sd) #combine data from rwl and ro groups 
fp <- dplyr::select(fp, - subjERR, - itemERR, - accuracy, - X, - condition) #removing variables

fpw <- tidyr::spread(fp, itemN, rt) #change to wide format 

splithalf.r(fpw,sims = 1000, graph = TRUE) #reliability

#form simple LDT
fsm.sd <- rename(fsm.sd, subjERR = baseline.subjERR, itemERR = baseline.itemERR)
fs <- rbind(fsb.sd, fsm.sd [,-1]) #combine data from rwl and ro groups 
fs <- dplyr::select(fs, - subjERR, - itemERR, - accuracy, - condition) #removing variables

fsw <- tidyr::spread(fs, itemN, rt) #change to wide format 

splithalf.r(fsw,sims = 1000, graph = TRUE) #reliability 

#semantic priming 
sp <- rbind(spb.sd, spm.sd) #combine data from rwl and ro groups 
sp <- dplyr::select(sp, - subjERR, - itemERR, - accuracy, - X, - condition) #removing variables

spw <- tidyr::spread(sp, itemN, rt) #change to wide format 

splithalf.r(spw,sims = 1000, graph = TRUE) #reliability

#semantic simple LDT
ss <- rbind(ssb.sd, ssm.sd) #combine data from rwl and ro groups 
ss <- dplyr::select(ss, - subjERR, - itemERR, - accuracy, - condition, - X) #removing variables

ssw <- tidyr::spread(ss, itemN, rt) #change to wide format 

splithalf.r(ssw,sims = 1000, graph = TRUE) #reliability 
