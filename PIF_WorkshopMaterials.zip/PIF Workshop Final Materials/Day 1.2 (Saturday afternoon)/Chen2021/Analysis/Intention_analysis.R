#############################
#the effects of intention
#Yingzhao Chen 
#last updated: 10/8/2020
#############################

sessionInfo()

#load packages
library(here)
library(psych)
library(HH)
library(rcompanion)
library(car)
library(sjstats)
library(lsr)
library(dplyr)
library(lme4)
library(lmerTest)

#load data
offline <- read.csv(here("Data", "Offline_tests.csv"))
spb <- read.csv(here("Data", "Spb_sd.csv"))
ssb <- read.csv(here("Data", "Ssb_sd.csv"))
spm <- read.csv(here("Data", "Spm_sd.csv"))
ssm <- read.csv(here("Data", "Ssm_sd.csv"))
fpb <- read.csv(here("Data", "Fpb_sd.csv"))
fsb <- read.csv(here("Data", "Fsb_sd.csv"))
fpm <- read.csv(here("Data", "Fpm_sd.csv"))
fsm <- read.csv(here("Data", "Fsm_sd.csv"))

#data preparation 
offline$Intention <- factor(offline$Intention, 
                            levels = c("Y", "N"), labels = c("1", "0"))

offline$Group <- factor(offline$Group,
                        levels = c("Bi","Mono"), 
                        labels = c("RWL","RO")) 

offline$Form <- offline$FormTarget - 32 + offline$FormFiller


#intention in offline tests

#descriptives
psych::describeBy(offline, 
           list(offline$Group, offline$Intention))

HH::interaction2wt(FormTotal~Group*Intention, data = offline) #plot
HH::interaction2wt(Meaning~Group*Intention, data = offline[-47,]) #plot exluding NA


rcompanion::groupwiseMean(FormTotal~Group + Intention,
                          data = offline, conf = .95)
rcompanion::groupwiseMean(Meaning~Group + Intention,
                          data = offline[-47, ], conf = .95)

#check assumptions for ANOVA 

car::leveneTest(offline$FormTotal,
           interaction(offline$Group, offline$Intention), center = median)
car::leveneTest(offline$Meaning,
                interaction(offline$Group, offline$Intention), center = median)

shapiro.test(offline$FormTotal)
shapiro.test(offline$Meaning)

#ANOVA
f<-aov(Form~Group*Intention, data = offline[-47,]) #form
Anova(f, type="III")#with type III Sum of Square 

m<-aov(Meaning~Group*Intention, data = offline) #meaning
Anova(m, type="III")

sjstats::anova_stats(m) #SPSS anova table
sjstats::anova_stats(f)

#simple effects analysis for the significant interaction effect in m 
#new variable combing Intention and Group 
offline$IG [offline$Intention == "1" & offline$Group == "RWL"] <- "IB" 
offline$IG [offline$Intention == "0" & offline$Group == "RWL"] <- "UB"
offline$IG [offline$Intention == "1" & offline$Group == "RO"] <- "IM"
offline$IG [offline$Intention == "0" & offline$Group == "RO"] <- "UM"

offline$IG <- factor(offline$IG)

#setting contrasts 
intention_RWL <- c(-1, 0, 1, 0)
intention_RO <- c(0, 1, 0, -1)
IG_effects <- cbind(intention_RO,intention_RWL)
contrasts(offline$IG) <- IG_effects
offline$IG

IG <- aov(Meaning ~ IG, data = offline)
summary.lm(IG)

#alternative: follow-up t tests (reported)
rwl <- offline[ which(offline$Group == 'RWL'), ]
ro <- offline[ which(offline$Group == 'RO'), ]


t.test(Meaning ~ Intention,
       conf.level = .95, var.equal = FALSE, data = rwl)

t.test(Meaning ~ Intention,
       conf.level = .95, var.equal = FALSE, data = ro)
p<-c(.03,.47) 
p.adjust(p,method = "fdr",n=length(p)) #adjusted p
cohensD(rwl$Meaning ~ rwl$Intention) #cohen's d
cohensD(ro$Meaning ~ ro$Intention)


#Intention in semantic priming 
#RWL group 
#data preparation 
ssb <- rename(ssb, brt = rt, bitemERR = itemERR, bsubjERR = subjERR )
ssb <- select(ssb, - accuracy, - X) #removing unnecessary variables
spb <- select(spb, - X, - accuracy) #removing unnecessary variables

spb <- spb[ which(spb$condition == '1'|
                    spb$condition == '2'), ]
ssb <- ssb[ which(ssb$condition == '1'|
                    ssb$condition == '2'), ]

ssb$brtinv <- ( - 1000 / ssb$brt) #RT transforming
spb$rtinv <- ( - 1000 / spb$rt)

ssb$condition <- factor(ssb$condition)
spb$condition <- factor(spb$condition)

sb <- left_join(spb, ssb, copy = FALSE) #merge priming and simple LDT RT data 

intention <- select(offline, 
                    Participant, Intention)
intention <- rename(intention, participant = Participant)

sb <- left_join(sb, intention)
sb$Intention <- factor(sb$Intention)

sbi <- sb[ which(sb$Intention == '1'), ] #intentional learners
sbu <- sb[ which(sb$Intention == '0'), ] #unintentional learners

#mixed effects modelling
contrasts(sbi$condition) <- contr.treatment(2, base = 2)
contrasts(sbu$condition) <- contr.treatment(2, base = 2)

sbi1 <- lmer(rtinv ~ condition + 
             (1|participant) + (1|itemN), data = sbi, REML = FALSE)
summary(sbi1)
AIC(sbi1)

sbi2 <- lmer(rtinv ~ condition + 
               (1+condition|participant) + (1|itemN), data = sbi, REML = FALSE)
summary(sbi2)
AIC(sbi2)

sbi3 <- lmer(rtinv ~ condition + 
               (1+condition|participant) + (1+condition|itemN), data = sbi, REML = FALSE)
summary(sbi2)
AIC(sbi2)

anova(sbi1,sbi2)

sbu1 <- lmer(rtinv ~ condition + 
               (1|participant) + (1|itemN), data = sbu, REML = FALSE)
summary(sbu1)
AIC(sbu1)

sbu2 <- lmer(rtinv ~ condition +
               (1+condition|participant) + (1|itemN), data = sbu, REML = FALSE)
summary(sbu2)
AIC(sbu2)

#Intention in semantic priming 
#RO group 
ssm <- rename(ssm, brt = rt, bitemERR = itemERR, bsubjERR = subjERR )
ssm <- select(ssm, - accuracy, - X) #removing unnecessary variables
spm <- select(spm, - X, - accuracy) #removing unnecessary variables

spm <- spm[ which(spm$condition == '1'|
                    spm$condition == '2'), ]
ssm <- ssm[ which(ssm$condition == '1'|
                    ssm$condition == '2'), ]

ssm$brtinv <- ( - 1000 / ssm$brt) #RT transforming
spm$rtinv <- ( - 1000 / spm$rt)

ssm$condition <- factor(ssm$condition)
spm$condition <- factor(spm$condition)

sm <- left_join(spm, ssm, copy = FALSE) #merge priming and simple LDT RT data 

sm <- left_join(sm, intention)
sm$Intention <- factor(sm$Intention)

smi <- sm[ which(sm$Intention == '1'), ] #intentional learners
smu <- sm[ which(sm$Intention == '0'), ] #unintentional learners

#mixed effects modelling
contrasts(smi$condition) <- contr.treatment(2, base = 2)
contrasts(smu$condition) <- contr.treatment(2, base = 2)

smi1 <- lmer(rtinv ~ condition + 
               (1|participant) + (1|itemN), data = smi, REML = FALSE)
summary(smi1)
AIC(smi1)

smi2 <- lmer(rtinv ~ condition +
               (1 + condition|participant) + (1|itemN), data = smi, REML = FALSE)
summary(smi2)
AIC(smi2)

smu1 <- lmer(rtinv ~ condition + 
               (1|participant) + (1|itemN), data = smu, REML = FALSE)
summary(smu1)
AIC(smu1)

smu2 <- lmer(rtinv ~ condition +
               (1 + condition|participant) + (1|itemN), data = smu, REML = FALSE)
summary(smu2)
AIC(smu2)

smu3 <- lmer(rtinv ~ condition +
               (1 + condition|participant) 
             + (1+ condition|itemN), data = smu, REML = FALSE)
summary(smu3)
AIC(smu3)

anova(smu1, smu2, smu3)
#Intention in form priming 
#RWL group 
#data preparation 
fsb <- rename(fsb, brt = rt, bitemERR = itemERR, bsubjERR = subjERR )
fsb <- select(fsb, - accuracy) #removing unnecessary variables
fpb <- select(fpb, - X, - accuracy) #removing unnecessary variables

fpb <- fpb[ which(fpb$condition == '1'|
                    fpb$condition == '2'|
                    fpb$condition == '3'), ]
fsb <- fsb[ which(fsb$condition == '1'|
                    fsb$condition == '2'|
                    fsb$condition == '3'), ]

fsb$brtinv <- ( - 1000 / fsb$brt) #RT transforming
fpb$rtinv <- ( - 1000 / fpb$rt)

fsb$condition <- factor(fsb$condition)
fpb$condition <- factor(fpb$condition)

fb <- left_join(fpb, fsb, copy = FALSE) #merge priming and simple LDT RT data 

fb <- left_join(fb, intention)
fb$Intention <- factor(fb$Intention)

fbi <- fb[ which(fb$Intention == '1'), ] #intentional learners
fbu <- fb[ which(fb$Intention == '0'), ] #unintentional learners

#mixed effects modelling
contrasts(fbi$condition) <- contr.treatment(3, base = 3)
contrasts(fbu$condition) <- contr.treatment(3, base = 3)

fbi1 <- lmer(rtinv ~ condition + 
               (1|participant) + (1|itemN), data = fbi, REML = FALSE)
summary(fbi1)
AIC(fbi1)

fbi2 <- lmer(rtinv ~ condition +
               (1 + condition|participant) + (1|itemN), data = fbi, REML = FALSE)
summary(fbi2)
AIC(fbi2)

fbu1 <- lmer(rtinv ~ condition + 
               (1|participant) + (1|itemN), data = fbu, REML = FALSE)
summary(fbu1)
AIC(fbu1)

fbu2 <- lmer(rtinv ~ condition +
               (1 + condition|participant) + (1|itemN), data = fbu, REML = FALSE)
summary(fbu2)
AIC(fbu2)

#Intention in form priming 
#RO group 
#data preparation 
fsm <- rename(fsm, brt = rt)
fsm <- select(fsm, - X, - accuracy) #removing unnecessary variables
fpm <- select(fpm, - X, - accuracy) #removing unnecessary variables

fpm <- fpm[ which(fpm$condition == '1'|
                    fpm$condition == '2'|
                    fpm$condition == '3'), ]
fsm <- fsm[ which(fsm$condition == '1'|
                    fsm$condition == '2'|
                    fsm$condition == '3'), ]

fsm$brtinv <- ( - 1000 / fsm$brt) #RT transforming
fpm$rtinv <- ( - 1000 / fpm$rt)

fsm$condition <- factor(fsm$condition)
fpm$condition <- factor(fpm$condition)

fm <- left_join(fpm, fsm, copy = FALSE) #merge priming and simple LDT RT data 

fm <- left_join(fm, intention)
fm$Intention <- factor(fm$Intention)

fmi <- fm[ which(fm$Intention == '1'), ] #intentional learners
fmu <- fm[ which(fm$Intention == '0'), ] #unintentional learners

#mixed effects modelling
contrasts(fmi$condition) <- contr.treatment(3, base = 3)
contrasts(fmu$condition) <- contr.treatment(3, base = 3)

fmi1 <- lmer(rtinv ~ condition + 
               (1|participant) + (1|itemN), data = fmi, REML = FALSE)
summary(fmi1)
AIC(fmi1)

fmi2 <- lmer(rtinv ~ condition +
               (1 + condition|participant) + (1|itemN), data = fmi, REML = FALSE)
summary(fmi2)
AIC(fmi2)

fmu1 <- lmer(rtinv ~ condition + 
               (1|participant) + (1|itemN), data = fmu, REML = FALSE)
summary(fmu1)
AIC(fmu1)

fmu2 <- lmer(rtinv ~ condition +
               (1 + condition|participant) + (1|itemN), data = fmu, REML = FALSE)
summary(fmu2)
AIC(fmu2)

