setwd("G:/My Drive/R_Analyses/ListeningCV/DataPacket_Version1.0/Construction")

#### Step 1 - Reading and Merging Raw Data #### 
setwd(".")

#packages
library(tidyverse)

#list of raw data files
files <- list.files(".\\RawData", pattern = "\\.txt")

#initialize dataframe
all <- data.frame()


#LOOP TO READ AND MERGE FILES#
setwd(".//RawData")

for(i in files){
     
     ##read data
     d<-read.delim(paste0(i), sep = "\t",header = F, skip =6)
     
     ##select columns
     d<-select(d,2,6, 8, 14:15)
     
     #bind rows
     all <- rbind(all, d) 
}

#name columns
names<-c("sub", "trial","event", "acc","rt")
names(all) <- names


#write csv
setwd("..")
write.csv(all, file = ".//CleanedData/Con_clean1.csv", row.names = F)

### Step 2 - Cleaning Data ####
#clear console and environment
cat("\014")
rm(list=ls())

#packages
library(tidyverse)

#read in raw data
d <- read.csv(".//CleanedData/Con_clean1.csv", stringsAsFactors = F)

#keep only Test trials
d<- filter(d,grepl("^Test_\\dv",event))

#add group info

d$group <- ifelse(d$sub>100 & d$sub<200, "bi",
                  "mono")


##bring in sti info to compute offset RT and add item no. 
sti_info <- read.csv("con_StiDur.csv", stringsAsFactors = T) ## bring in sti duration information

d<-left_join(d,sti_info,by="trial")

d$trial<-NULL
d$event<-NULL

#identfy potential problematic items
d$score<-ifelse(d$acc =="C", 1, 0)

d_mono<-d[d$group=="mono",]

attach(d_mono)
tapply(score,item,mean) 

# using NS data to determine bad items
# bad items: none
detach(d_mono)

write.csv(d, file = ".//CleanedData/Con_clean2.csv", row.names = F)

#### step 3 main analysis ####
#clear console and environment
cat("\014")
rm(list=ls())

##start reliability - Accuracy
d<- read.csv(".//CleanedData/Con_clean2.csv",stringsAsFactors = F)

#reliability - accuracy

reliability<-d %>% dplyr::select("sub", "item","score")

library(tidyr)
reliability_wide <- spread(reliability, item, score)
reliability_wide$sub<-NULL

psychometric::alpha(reliability_wide) #0.75

#RT analysis
d.rt<- d[d$score==1,]

#compute offset rt
d.rt$rt.offset<-d.rt$rt-d.rt$duration

d.rt<-d.rt[d.rt$rt>149,]
d.rt<-d.rt[d.rt$rt.offset<4501,]

library(dplyr)
reliabilityRT<-d.rt %>% dplyr::select("sub", "item", "rt")

library(tidyr)
reliabilityRT_wide <- spread(reliabilityRT, item, rt)
reliabilityRT_wide$sub<-NULL

# Calculating total mean RT for reliability
rt_e <- rowMeans(reliabilityRT_wide[, c(TRUE, FALSE)], na.rm=T)  # with even items
rt_o <- rowMeans(reliabilityRT_wide[, c(FALSE, TRUE)], na.rm=T)  # with odd items

# Correlating RTs from even and odd items
r <- cor(rt_e, rt_o) 
r #0.92

#compute mean accuracy
detach(package:Rmisc)
detach(package:plyr)  
library(dplyr)

con_acc<-d %>% group_by(sub) %>% summarise(synacc = mean (score))

##compute mean RT
con_rt<-d.rt %>% group_by(sub) %>% summarise(synrt = mean (rt))

##compute CV
con_cv<-d.rt %>% group_by(sub) %>% summarise(syncv = sd(rt)/mean (rt))

##join three data frames for final analysis
con_final<-left_join(con_acc,con_cv, by = "sub")
con_final<-left_join(con_final,con_rt, by = "sub")

write.csv(con_final, "con_final.csv", row.names = F)

###############
#clear console and environment
cat("\014")
rm(list=ls())

##correlation
con_final<-read.csv("con_final.csv")
plot(con_final$syncv,con_final$synrt)


library("Hmisc")
cor_1 <- rcorr(as.matrix(con_final[,2:4])) #overall
cor_1

con_final$group <- ifelse(con_final$sub>100 & con_final$sub<200, 
                          "bi",
                          "mono")

cor_2 <- rcorr(as.matrix(con_final[con_final$group=="mono",2:4])) #NS only
cor_2

cor_3 <- rcorr(as.matrix(con_final[con_final$group=="bi",2:4])) #NNS only
cor_3

#descriptives
##CV
library(Rmisc)
summarySE(data=con_final,
          "syncv",
          groupvars = "group",
          conf.interval = 0.95)

library(rcompanion)

groupwiseMean(syncv~ group, 
              data   = con_final, 
              conf   = 0.95, 
              digits = 3)

t.test(syncv~group,data=con_final)

library(Rmisc)
summarySE(data=con_final,
          "syncv",
          conf.interval = 0.95)

library(rcompanion)
groupwiseMean(syncv~ 1, 
              data   = con_final, 
              conf   = 0.95, 
              digits = 3)


##accuracy
library(Rmisc)
summarySE(data=con_final,
          "synacc",
          groupvars = "group",
          conf.interval = 0.95)

library(rcompanion)

groupwiseMean(synacc~ group, 
              data   = con_final, 
              conf   = 0.95, 
              digits = 3)

library(Rmisc)
summarySE(data=con_final,
          "synacc",
          conf.interval = 0.95)

library(rcompanion)
groupwiseMean(synacc~ 1, 
              data   = con_final, 
              conf   = 0.95, 
              digits = 3)

##rt
library(Rmisc)
summarySE(data=con_final,
          "synrt",
          groupvars = "group",
          conf.interval = 0.95)

library(rcompanion)

groupwiseMean(synrt~ group, 
              data   = con_final, 
              conf   = 0.95, 
              digits = 3)

library(Rmisc)
summarySE(data=con_final,
          "synrt",
          conf.interval = 0.95)

library(rcompanion)
groupwiseMean(synrt~ 1, 
              data   = con_final, 
              conf   = 0.95, 
              digits = 3)

