
d<-read.csv('lexdecision.csv', header = T)
View(d)
summary(d)

library (ggplot2)

######In-class Ex1############
######Scatterplot
################################
q1<-ggplot(d, aes(x=meanRT, y=Frequency))

q1+geom_point() +
  geom_smooth(method=lm, se=TRUE, level=0.95) + 
  scale_y_continuous(name="Logarithmically Transformed Lemma Frequencies", limits = c(0,8))+ ## Step 3b: manipulate breaks and scales
  ###for y: breaks = seq(0,20,2) <- from 0 to 20, one break in every 2 units
  scale_x_continuous(name="Item Mean Reaction Time (RT)")

######In-class Ex2############
######Line graph
################################

q2<-ggplot(data=d, aes(x=NativeLanguage, y=meanRT))
q2

q2+
  stat_summary(fun = mean, geom = "point") + ## Step 2a: add the mean as a point
  stat_summary(fun = mean, geom = "line", aes(group = "NativeLanguage")) + ##Step2b: add the line between groups
  stat_summary(fun.data = mean_cl_boot, geom = "errorbar", width = 0.3) + ##Step 2c: add error bars 
  scale_y_continuous(name="Item Mean Reaction Time (RT)", limits = c(6,7))+ ##Step 3a: fix y-axis
  scale_x_discrete(name="Native Language") ##Step 3b: fix x-axis


########boxplot
q3<-ggplot(data=d, aes(x=NativeLanguage, y=meanRT)) ##Step 1: groundwork
q3

q3+
  geom_boxplot() +  ##Step 2a: choose the right plot (boxplot)
  geom_dotplot(binwidth = 0.01, binaxis = "y", dotsize = 1.5, stackdir='center')+ ##Step 2b: add dots
  scale_y_continuous(name="Item Mean Reaction Time (RT)", breaks=seq(6,7,0.1), limits=c(6,7))+ ##Step 3a: fix y-axis
  scale_x_discrete(name="Native Language") ##Step 3b: fix x-axis
