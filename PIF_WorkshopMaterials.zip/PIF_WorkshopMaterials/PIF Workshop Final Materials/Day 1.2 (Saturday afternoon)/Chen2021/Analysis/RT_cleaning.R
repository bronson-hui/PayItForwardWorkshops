#############################
#cleaning of RT data
#Yingzhao Chen
#last updated: 5/13/2020
#############################

sessionInfo()

#load packages
library(here)
library(trimr)
library(dplyr)

#load data
fpb.raw <- read.csv(here("Data", "Fpb_raw.csv"))
fsb.raw <- read.csv(here("Data", "Fsb_raw.csv"))
spb.raw <- read.csv(here("Data", "Spb_raw.csv"))
ssb.raw <- read.csv(here("Data", "Ssb_raw.csv"))
fpm.raw <- read.csv(here("Data", "Fpm_raw.csv"))
fsm.raw <- read.csv(here("Data", "Fsm_raw.csv"))
spm.raw <- read.csv(here("Data", "Spm_raw.csv"))
ssm.raw <- read.csv(here("Data", "Ssm_raw.csv"))

#trim 300ms-2000ms, 3SD participant, trimr 
#form priming 
#rwl/bimodal group 
fpb.raw <- rename(fpb.raw, 
                 participant = ID, accuracy = error, condition = Condition) #rename for trimr
fpb.raw$accuracy <- factor(fpb.raw$accuracy,
                          levels = c(0, 1), labels = c("1", "0")) #recode for trimr
fpb.rt <- absoluteRT(data = fpb.raw, 
                    minRT = 300, maxRT = 2000, returnType = "raw") #trim rt below 300 and above 2000ms
fpb.sd <- sdTrim(data = fpb.rt, minRT = 300, sd = 3, 
                perCondition = FALSE, perParticipant = TRUE, returnType = "raw")
write.csv(fpb.sd, file = "Fpb_sd.csv")

#form simple LDT
#rwl/bimodal group
fsb.raw <- rename(fsb.raw, 
                  participant = ID, accuracy = error, condition = Condition)
fsb.raw$accuracy <- factor(fsb.raw$accuracy,
                           levels = c(0, 1), labels = c("1", "0")) #recode for trimr
fsb.rt <- absoluteRT(data = fsb.raw, 
                     minRT = 300, maxRT = 2000, returnType = "raw") #trim rt below 300 and above 2000ms
fsb.sd <- sdTrim(data = fsb.rt, minRT = 300, sd = 3, 
                 perCondition = FALSE, perParticipant = TRUE, returnType = "raw")
write.csv(fsb.sd, file = "Fsb_sd.csv")

#semantic priming
#rwl/bimodal group
spb.raw <- rename(spb.raw, 
                  participant = ID, accuracy = error, condition = Condition) #rename for trimr
spb.raw$accuracy <- factor(spb.raw$accuracy,
                           levels = c(0, 1), labels = c("1", "0")) #recode for trimr
spb.rt <- absoluteRT(data = spb.raw, 
                     minRT = 300, maxRT = 2000, returnType = "raw") #trim rt below 300 and above 2000ms
spb.sd <- sdTrim(data = spb.rt, minRT = 300, sd = 3, 
                 perCondition = FALSE, perParticipant = TRUE, returnType = "raw")
write.csv(spb.sd, file = "Spb_sd.csv")

#semantic simple LDT
#rwl/bimodal group
ssb.raw <- rename(ssb.raw, 
                  participant = ID, accuracy = error, condition = Condition)
ssb.raw$accuracy <- factor(ssb.raw$accuracy,
                           levels = c(0, 1), labels = c("1", "0")) #recode for trimr
ssb.rt <- absoluteRT(data = ssb.raw, 
                     minRT = 300, maxRT = 2000, returnType = "raw") #trim rt below 300 and above 2000ms
ssb.sd <- sdTrim(data = ssb.rt, minRT = 300, sd = 3, 
                 perCondition = FALSE, perParticipant = TRUE, returnType = "raw")
write.csv(ssb.sd, file = "Ssb_sd.csv")

#form priming
#ro/monomodal group 
fpm.raw <- rename(fpm.raw, 
                  participant = ID, accuracy = error, condition = Condition) #rename for trimr
fpm.raw$accuracy <- factor(fpm.raw$accuracy,
                           levels = c(0, 1), labels = c("1", "0")) #recode for trimr
fpm.rt <- absoluteRT(data = fpm.raw, 
                     minRT = 300, maxRT = 2000, returnType = "raw") #trim rt below 300 and above 2000ms
fpm.sd <- sdTrim(data = fpm.rt, minRT = 300, sd = 3, 
                 perCondition = FALSE, perParticipant = TRUE, returnType = "raw")
write.csv(fpm.sd, file = "Fpm_sd.csv")

#form simple LDT
#ro/monomodal group 
fsm.raw <- rename(fsm.raw, 
                  participant = ID, accuracy = error, 
                  condition = Condition)
fsm.raw$accuracy <- factor(fsm.raw$accuracy,
                           levels = c(0, 1), labels = c("1", "0")) #recode for trimr
fsm.rt <- absoluteRT(data = fsm.raw, 
                     minRT = 300, maxRT = 2000, returnType = "raw") #trim rt below 300 and above 2000ms
fsm.sd <- sdTrim(data = fsm.rt, minRT = 300, sd = 3, 
                 perCondition = FALSE, perParticipant = TRUE, returnType = "raw")
write.csv(fsm.sd, file = "Fsm_sd.csv")

#semantic priming 
#ro/monomodal group 
spm.raw <- rename(spm.raw, 
                  participant = ID, accuracy = error) #rename for trimr
spm.raw$accuracy <- factor(spm.raw$accuracy,
                           levels = c(0, 1), labels = c("1", "0")) #recode for trimr
spm.rt <- absoluteRT(data = spm.raw, 
                     minRT = 300, maxRT = 2000, returnType = "raw") #trim rt below 300 and above 2000ms
spm.sd <- sdTrim(data = spm.rt, minRT = 300, sd = 3, 
                 perCondition = FALSE, perParticipant = TRUE, returnType = "raw")
write.csv(spm.sd, file = "Spm_sd.csv")

#semantic simple LDT
#ro/monomodal group 
ssm.raw <- rename(ssm.raw, 
                  participant = ID, accuracy = error, condition = Condition)
ssm.raw$accuracy <- factor(ssm.raw$accuracy,
                           levels = c(0, 1), labels = c("1", "0")) #recode for trimr
ssm.rt <- absoluteRT(data = ssm.raw, 
                     minRT = 300, maxRT = 2000, returnType = "raw") #trim rt below 300 and above 2000ms
ssm.sd <- sdTrim(data = ssm.rt, minRT = 300, sd = 3, 
                 perCondition = FALSE, perParticipant = TRUE, returnType = "raw")
write.csv(ssm.sd, file = "Ssm_sd.csv")

