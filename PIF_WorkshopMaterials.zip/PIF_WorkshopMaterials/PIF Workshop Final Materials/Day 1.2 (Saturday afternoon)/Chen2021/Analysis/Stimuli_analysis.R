#################################
#stimuli characteristics analysis
#Yingzhao Chen
#last updated: 5/13/2020   
#################################

sessionInfo()

#load packages

library(here)
library(psych)

#load data
fp.s <- read.csv(here("Data", "Fp_stimuli.csv"))
sp.s <- read.csv(here("Data", "Sp_stimuli.csv"))

#form priming stimuli  
fp.s$Condition <- factor(fp.s$Condition)
psych::describeBy(fp.s, fp.s$Condition)

#compare group means 
#check assumptions
#normality
qqnorm(fp.s$CELEX)
qqline(fp.s$CELEX)
qqnorm(fp.s$N)
qqline(fp.s$N)
qqnorm(fp.s$length)
qqline(fp.s$length)
shapiro.test(fp.s$CELEX)
shapiro.test(fp.s$N)
shapiro.test(fp.s$length)

#non parametric tests for comparison 
CELEX.f <- kruskal.test(CELEX~Condition,
                       data = fp.s)
CELEX.f

L.f <- kruskal.test(length~Condition,
                   data = fp.s)
L.f

N.f <- kruskal.test(N~Condition,
                   data = fp.s)
N.f

#semantic priming stimuli 
sp.s$Condition <- factor(sp.s$Condition)
psych::describeBy(sp.s, sp.s$Condition)

#compare group means
#check assumptions 
#normality
qqnorm(sp.s$CELEX)
qqline(sp.s$CELEX)
qqnorm(sp.s$N)
qqline(sp.s$N)
qqnorm(sp.s$length)
qqline(sp.s$length)

shapiro.test(sp.s$CELEX)
shapiro.test(sp.s$N)
shapiro.test(sp.s$length)

#Mann Whitney U tests

L.s <- wilcox.test(data = sp.s,
                 length~Condition,
                 conf.int = TRUE, conf.level = .95,
                 var.equal = FALSE, paired = FALSE, 
                 exact = FALSE, correct = FALSE)
L.s

CELEX.s <- wilcox.test(data = sp.s,
                   CELEX~Condition,
                   conf.int = TRUE, conf.level = .95,
                   var.equal = FALSE, paired = FALSE, 
                   exact = FALSE, correct = FALSE)
CELEX.s

#effect sizes for Mann Whitney U tests 
z.L <- qnorm(L.s$p.value/2) #z scores
r.L <- z.L/sqrt(64)
r.L

z.CELEX <- qnorm(CELEX.s$p.value/2) #z scores
r.CELEX <- z.CELEX/sqrt(64)
r.CELEX
