####################################################
#analysis of form recognition and form-meaning tests
#Yingzhao Chen
#last updated: 10/08/2020
####################################################
sessionInfo()

####load packages####

library(here)
library(psych)
library(rcompanion)
library(car)
library(lsr)
library(QuantPsyc)
library(relaimpo)
library(car)
library(lm.beta)
library(ppcor)
library(tidyr)
library(reshape)

####load data using here####
offline <- read.csv(here("Data","Offline_tests.csv"))
stories <- read.csv(here("Data", "Form_reliability.csv"))
stories_m <- read.csv(here("Data", "Meaning_reliability.csv"))

####transform condition and participant into categorical variables#### 
offline$Participant <- factor(offline$Participant)
offline$Group <- factor(offline$Group,
                                levels = c("Bi","Mono"), 
                                labels = c("RWL","RO")) 
offline$Group
offline$Intention <- factor(offline$Intention,
                          levels = c("Y","N"),
                          labels = c("1","0"))
offline$Intention

offline$Form <- offline$FormTarget - 32 + offline$FormFiller

####descriptive statistics using psych#### 
describeBy(offline, offline$Group)
describeBy(offline$FormTarget, offline$Group)
describeBy(offline$Form, offline$Group)

####95% CI using rcompanion####
groupwiseMean(FormTotal~Group, 
              data = offline,conf = .95, digits = 5)
groupwiseMean(Form~Group, 
              data = offline,conf = .95, digits = 5)

groupwiseMean(Meaning~Group, 
              data = offline [-47,], conf = .95, digits = 5) #excluding row 47 NA


####checking the assumption of normality#### 
shapiro.test(offline$LOR)
shapiro.test(offline$AoArrival)
shapiro.test(offline$Age)
shapiro.test(offline$SelfReading)
shapiro.test(offline$SelfListening)
shapiro.test(offline$SelfSpeaking)
shapiro.test(offline$SelfWriting)

####Mann-Whitney U tests for group differences#### 
age.t = wilcox.test(data = offline,Age~Group,
                  conf.int = TRUE, conf.level=.95,
                  var.equal = FALSE, paired = FALSE, 
                  exact = FALSE, correct = FALSE)

aoa.t=wilcox.test(data = offline,AoArrival~Group,
                  conf.int = TRUE, conf.level = .95,
                  var.equal = FALSE, paired = FALSE, 
                  exact = FALSE, correct = FALSE)

lor.t=wilcox.test(data = offline,LOR~Group,
                  conf.int = TRUE, conf.level = .95,
                  var.equal = FALSE, paired = FALSE, 
                  exact = FALSE, correct = FALSE)


lis.t=wilcox.test(data = offline,SelfListening~Group,
                  conf.int = TRUE, conf.level = .95,
                  var.equal = FALSE, paired = FALSE, 
                  exact = FALSE, correct = FALSE)


read.t=wilcox.test(data = offline,SelfReading~Group,
                  conf.int = TRUE, conf.level = .95,
                  var.equal = FALSE, paired = FALSE, 
                  exact = FALSE, correct = FALSE)

speak.t=wilcox.test(data = offline,SelfSpeaking~Group,
                   conf.int = TRUE, conf.level = .95,
                   var.equal = FALSE, paired = FALSE, 
                   exact = FALSE, correct = FALSE)

write.t=wilcox.test(data = offline,SelfWriting~Group,
                   conf.int = TRUE, conf.level = .95,
                   var.equal = FALSE, paired = FALSE, 
                   exact = FALSE, correct = FALSE)
age.t
aoa.t
lor.t
lis.t
read.t
speak.t
write.t

####effect sizes r for the Mann-Whitney U tests#### 
z.age <- qnorm(age.t$p.value/2) #z for z scores
r.age <- z.age/sqrt(50)
r.age

z.aoa <- qnorm(aoa.t$p.value/2)
r.aoa <- z.aoa/sqrt(50)
r.aoa

z.lor <- qnorm(lor.t$p.value/2) #z for z scores
r.lor <- z.lor/sqrt(50)
r.lor

z.write <- qnorm(write.t$p.value/2)
r.write <- z.write/sqrt(50)
r.write

z.lis <- qnorm(lis.t$p.value/2) #z for z scores
r.lis <- z.lis/sqrt(50)
r.lis

z.read <- qnorm(read.t$p.value/2) #z for z scores
r.read <- z.read/sqrt(50)
r.read

z.speak <- qnorm(speak.t$p.value/2) #z for z scores
r.speak <- z.speak/sqrt(50)
r.speak


###########################################
#RQ1
#group comparison of form and meaning tests
#independent sample T tests 
###########################################

#Assumptions 
#nomral distribution
shapiro.test(offline$FormTotalSubtract)
shapiro.test(offline$Meaning)

#equal variance using car
leveneTest(offline$FormTotal,offline$Group)
leveneTest(offline$Meaning,offline$Group)

#t tests 
t.test(FormTotal~Group,
       conf.level = .95, var.equal = TRUE,
       data = offline)

t.test(Form~Group,
       conf.level = .95, var.equal = FALSE,
       data = offline)

t.test(Meaning~Group,
       conf.level = .95, var.equal = TRUE,
       data = offline)

#FDR correction for multiple comparisons
p <- c(.02, .01)
p.adjust(p,method = "fdr", n = length(p))

#cohen's d effect size using lsr
cohensD(offline$Meaning~offline$Group)
cohensD(offline$FormTotal~offline$Group)
cohensD(offline$Form~offline$Group)


###########################################
#RQ2
#multiple regressions 
#standard multiple regression model
###########################################

#test of multicollinearity 

corm <- cor(offline[-47, c(7, 8,25,9,11)],
          method = "spearman") #correlation matrix 
corm

#data preparation

df.lm <- offline[, c(1, 2, 7, 8, 9, 11,25)] #extracting variables needed for analysis

df.lm$Group <- factor(df.lm$Group,
                      levels = c("RWL", "RO"))

df.lm$meancenlis <- df.lm$SelfListening - mean(df.lm$SelfListening) #mean centered
df.lm$meancenread <- df.lm$SelfReading - mean(df.lm$SelfReading) #mean centered

contrasts(df.lm$Group) <- contr.treatment(2, base = 2) #set contrast

#model building for both groups 

mform <- lm(Form~Group*(meancenlis + meancenread),
         data = df.lm)

summary(mform)

lm.beta(mform) #standardized regression coefficients
calc.relimp(mform) #sr
confint(mform) #CI for regression coefficients 

plot(mform) #diagnostics
vif(mform) #vif

mmeaning <- lm(Meaning~Group*(meancenlis + meancenread),
             data = df.lm)

summary(mmeaning)

lm.beta(mmeaning)
calc.relimp(mmeaning)
confint(mmeaning)

plot(mmeaning)
vif(mmeaning)

#model buidling for individual groups
#rwl group 
#form recognition 

rwl <- df.lm[ which(df.lm$Group=='RWL'), ] #RWL group data

rwl$Group <- factor(rwl$Group)

mrwl.f <- lm(Form~meancenread + meancenlis, data = rwl) #rwl model 1

summary(mrwl.f)

plot(mrwl.f) #diagnostics
vif(mrwl.f)

mrwl.f1 <- lm(Form~meancenlis + meancenread, data = rwl[-12,]) #removing outliers

summary(mrwl.f1)

plot(mrwl.f1)
vif(mrwl.f1)

lm.beta(mrwl,f1)
confint(mrwl.f1)
calc.relimp(mrwl,f1)

#ro group
#form recognition

ro <- df.lm[ which(df.lm$Group == 'RO'),] 
ro$Group <- factor(ro$Group)

mro.f <- lm(Form~meancenlis + meancenread, data = ro)

summary(mro.f)

plot(mro.f)
vif(mro.f)

lm.beta(mro.f)
confint(mro.f)
calc.relimp(mro.f)

####################################################
###########compare words in different stories#######
####################################################

####form recognition####
stories_long <- gather(stories,item,accuracy,item1 :item64 ) #change to long format 

stories_long$item[stories_long$item == "item4"] <- 4 #recode item 
stories_long$item[stories_long$item == "item5"] <- 5
stories_long$item[stories_long$item == "item7"] <- 7
stories_long$item[stories_long$item == "item10"] <- 10
stories_long$item[stories_long$item == "item13"] <- 13
stories_long$item[stories_long$item == "item15"] <- 15
stories_long$item[stories_long$item == "item16"] <- 16
stories_long$item[stories_long$item == "item18"] <- 18
stories_long$item[stories_long$item == "item19"] <- 19
stories_long$item[stories_long$item == "item20"] <- 20
stories_long$item[stories_long$item == "item22"] <- 22
stories_long$item[stories_long$item == "item23"] <- 23
stories_long$item[stories_long$item == "item24"] <- 24
stories_long$item[stories_long$item == "item26"] <- 26
stories_long$item[stories_long$item == "item27"] <- 27
stories_long$item[stories_long$item == "item29"] <- 29
stories_long$item[stories_long$item == "item32"] <- 32
stories_long$item[stories_long$item == "item33"] <- 33
stories_long$item[stories_long$item == "item35"] <- 35
stories_long$item[stories_long$item == "item44"] <- 44
stories_long$item[stories_long$item == "item45"] <- 45
stories_long$item[stories_long$item == "item46"] <- 46
stories_long$item[stories_long$item == "item48"] <- 48
stories_long$item[stories_long$item == "item49"] <- 49
stories_long$item[stories_long$item == "item50"] <- 50
stories_long$item[stories_long$item == "item52"] <- 52
stories_long$item[stories_long$item == "item54"] <- 54
stories_long$item[stories_long$item == "item56"] <- 56
stories_long$item[stories_long$item == "item58"] <- 58
stories_long$item[stories_long$item == "item60"] <- 60
stories_long$item[stories_long$item == "item61"] <- 61
stories_long$item[stories_long$item == "item62"] <- 62

stories_long$item <- as.numeric(stories_long$item)
stories_long <- subset(x = stories_long, !is.na(item))
summary(stories_long)

stories_long <- dplyr::select(stories_long, -Participant, -total)#aggregation
stories_long$item <- as.character(stories_long$item)
stories_acc <- stories_long[-1]
stories_long = aggregate(stories_acc, by = list(stories_long$item),
                         FUN = sum)
stories_long <-dplyr::rename(stories_long, item = Group.1)

stories_long$story <- numeric(length(stories_long$item))#create groups 

stories_long$story[stories_long$item == 23] <- 1
stories_long$story[stories_long$item == 24] <- 1
stories_long$story[stories_long$item == 33] <- 1
stories_long$story[stories_long$item == 44] <- 1
stories_long$story[stories_long$item == 46] <- 1
stories_long$story[stories_long$item == 49] <- 1
stories_long$story[stories_long$item == 52] <- 1
stories_long$story[stories_long$item == 62] <- 1

stories_long$story[stories_long$item == 4] <- 2
stories_long$story[stories_long$item == 5] <- 2
stories_long$story[stories_long$item == 7] <- 2
stories_long$story[stories_long$item == 26] <- 2
stories_long$story[stories_long$item == 27] <- 2
stories_long$story[stories_long$item == 29] <- 2
stories_long$story[stories_long$item == 45] <- 2
stories_long$story[stories_long$item == 48] <- 2

stories_long$story[stories_long$item == 10] <- 3
stories_long$story[stories_long$item == 13] <- 3
stories_long$story[stories_long$item == 15] <- 3
stories_long$story[stories_long$item == 32] <- 3
stories_long$story[stories_long$item == 35] <- 3
stories_long$story[stories_long$item == 50] <- 3
stories_long$story[stories_long$item == 54] <- 3
stories_long$story[stories_long$item == 56] <- 3

stories_long$story[stories_long$item == 16] <- 4
stories_long$story[stories_long$item == 18] <- 4
stories_long$story[stories_long$item == 19] <- 4
stories_long$story[stories_long$item == 20] <- 4
stories_long$story[stories_long$item == 22] <- 4
stories_long$story[stories_long$item == 58] <- 4
stories_long$story[stories_long$item == 60] <- 4
stories_long$story[stories_long$item == 61] <- 4

stories_long$story <- as.factor(stories_long$story)

#compare group means
#descriptives
describeBy(stories_long$accuracy, stories_long$story)
#check assumptions
#normality
qqnorm(stories_long$accuracy)
qqline(stories_long$accuracy)
shapiro.test(stories_long$accuracy)

#non parametric tests for comparison 
acc <- kruskal.test(accuracy ~ story,
                        data = stories_long)
acc

####meaning test####
stories_m_long <- gather(stories_m,item,accuracy,item1 :item32 ) #change to long format 

stories_m_long$item[stories_m_long$item == "item1"] <- 1 #recode item 
stories_m_long$item[stories_m_long$item == "item2"] <- 2
stories_m_long$item[stories_m_long$item == "item3"] <- 3
stories_m_long$item[stories_m_long$item == "item4"] <- 4
stories_m_long$item[stories_m_long$item == "item5"] <- 5
stories_m_long$item[stories_m_long$item == "item6"] <- 6
stories_m_long$item[stories_m_long$item == "item7"] <- 7
stories_m_long$item[stories_m_long$item == "item8"] <- 8
stories_m_long$item[stories_m_long$item == "item9"] <- 9
stories_m_long$item[stories_m_long$item == "item10"] <- 10
stories_m_long$item[stories_m_long$item == "item11"] <- 11
stories_m_long$item[stories_m_long$item == "item12"] <- 12
stories_m_long$item[stories_m_long$item == "item13"] <- 13
stories_m_long$item[stories_m_long$item == "item14"] <- 14
stories_m_long$item[stories_m_long$item == "item15"] <- 15
stories_m_long$item[stories_m_long$item == "item16"] <- 16
stories_m_long$item[stories_m_long$item == "item17"] <- 17
stories_m_long$item[stories_m_long$item == "item18"] <- 18
stories_m_long$item[stories_m_long$item == "item19"] <- 19
stories_m_long$item[stories_m_long$item == "item20"] <- 20
stories_m_long$item[stories_m_long$item == "item21"] <- 21
stories_m_long$item[stories_m_long$item == "item22"] <- 22
stories_m_long$item[stories_m_long$item == "item23"] <- 23
stories_m_long$item[stories_m_long$item == "item24"] <- 24
stories_m_long$item[stories_m_long$item == "item25"] <- 25
stories_m_long$item[stories_m_long$item == "item26"] <- 26
stories_m_long$item[stories_m_long$item == "item27"] <- 27
stories_m_long$item[stories_m_long$item == "item28"] <- 28
stories_m_long$item[stories_m_long$item == "item29"] <- 29
stories_m_long$item[stories_m_long$item == "item30"] <- 30
stories_m_long$item[stories_m_long$item == "item31"] <- 31
stories_m_long$item[stories_m_long$item == "item32"] <- 32

stories_m_long <- dplyr::select(stories_m_long, -Participant, -Total)#aggregation
stories_m_long <- subset(x = stories_m_long, !is.na(accuracy))
stories_m_long <- subset(x = stories_m_long, !is.na(item))

stories_m_acc <- stories_m_long[-1]
stories_m_long = aggregate(stories_m_acc, by = list(stories_m_long$item),
                         FUN = sum)
stories_m_long <-dplyr::rename(stories_m_long, item = Group.1)

stories_m_long$story <- numeric(length(stories_m_long$item))#create groups 

stories_m_long$item <- as.numeric(stories_m_long$item)
stories_m_long$story[stories_m_long$item == 2] <- 1
stories_m_long$story[stories_m_long$item == 3] <- 1
stories_m_long$story[stories_m_long$item == 7] <- 1
stories_m_long$story[stories_m_long$item == 9] <- 1
stories_m_long$story[stories_m_long$item == 17] <- 1
stories_m_long$story[stories_m_long$item == 19] <- 1
stories_m_long$story[stories_m_long$item == 31] <- 1
stories_m_long$story[stories_m_long$item == 32] <- 1

stories_m_long$story[stories_m_long$item == 6] <- 2
stories_m_long$story[stories_m_long$item == 8] <- 2
stories_m_long$story[stories_m_long$item == 10] <- 2
stories_m_long$story[stories_m_long$item == 12] <- 2
stories_m_long$story[stories_m_long$item == 13] <- 2
stories_m_long$story[stories_m_long$item == 14] <- 2
stories_m_long$story[stories_m_long$item == 16] <- 2
stories_m_long$story[stories_m_long$item == 24] <- 2

stories_m_long$story[stories_m_long$item == 1] <- 3
stories_m_long$story[stories_m_long$item == 4] <- 3
stories_m_long$story[stories_m_long$item == 5] <- 3
stories_m_long$story[stories_m_long$item == 18] <- 3
stories_m_long$story[stories_m_long$item == 23] <- 3
stories_m_long$story[stories_m_long$item == 25] <- 3
stories_m_long$story[stories_m_long$item == 26] <- 3
stories_m_long$story[stories_m_long$item == 29] <- 3

stories_m_long$story[stories_m_long$item == 11] <- 4
stories_m_long$story[stories_m_long$item == 15] <- 4
stories_m_long$story[stories_m_long$item == 20] <- 4
stories_m_long$story[stories_m_long$item == 21] <- 4
stories_m_long$story[stories_m_long$item == 22] <- 4
stories_m_long$story[stories_m_long$item == 27] <- 4
stories_m_long$story[stories_m_long$item == 28] <- 4
stories_m_long$story[stories_m_long$item == 30] <- 4

stories_m_long$story <- as.factor(stories_m_long$story)

summary(stories_m_long)

#compare group means
#descriptives
describeBy(stories_m_long$accuracy, stories_m_long$story)
#check assumptions
#normality
qqnorm(stories_m_long$accuracy)
qqline(stories_m_long$accuracy)
shapiro.test(stories_m_long$accuracy)

#non parametric tests for comparison 
acc_m <- kruskal.test(accuracy ~ story,
                    data = stories_m_long)
acc_m
