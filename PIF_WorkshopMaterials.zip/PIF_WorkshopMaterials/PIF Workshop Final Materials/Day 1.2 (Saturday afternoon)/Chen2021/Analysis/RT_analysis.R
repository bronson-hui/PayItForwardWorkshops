 #############################
#RT analysis
#Yingzhao Chen
#last updated: 10/9/2020
#############################

sessionInfo()

#load packages
library(here)
library(dplyr)
library(psych)
library(lme4)
library(lmerTest)

#load data
fpb <- read.csv(here("Data", "Fpb_sd.csv"))
fsb <- read.csv(here("Data","Fsb_sd.csv"))
offline <- read.csv(here("Data", "Offline_tests.csv"))
fpm <- read.csv(here("Data", "Fpm_sd.csv"))
fsm <- read.csv(here("Data","Fsm_sd.csv"))

spb <- read.csv(here("Data", "Spb_sd.csv"))
ssb <- read.csv(here("Data","Ssb_sd.csv"))
spm <- read.csv(here("Data", "Spm_sd.csv"))
ssm <- read.csv(here("Data","Ssm_sd.csv"))

rating <- select(offline, 
                 Participant, SelfReading, SelfListening) #extract self ratings
rating <- rename(rating, participant = Participant) 

#form RT
#rwl/bimodal group
#data preparation
fsb <- rename(fsb, brt = rt, bitemERR = itemERR, bsubjERR = subjERR )
fsb <- select(fsb, - accuracy) #removing unnecessary variables
fpb <- select(fpb, - X, - accuracy) #removing unnecessary variables

fpb <- fpb[ which(fpb$condition == '1'|
                    fpb$condition == '2'|
                    fpb$condition == '3'),]
fsb <- fsb[ which(fsb$condition == '1'|
                    fsb$condition == '2'|
                    fsb$condition == '3'),]

fsb$brtinv <- ( - 1000 / fsb$brt) #RT transforming
fpb$rtinv <- ( - 1000 / fpb$rt)

fsb$condition <- factor(fsb$condition)
fpb$condition <- factor(fpb$condition)

fb <- left_join(fpb, fsb, copy = FALSE) #merge priming and simple LDT RT data 
fb <- left_join(fb, rating, by = "participant") #add self ratings as a variable

#descriptives
describeBy(fpb, fpb$condition)
describeBy(fsb, fsb$condition)

#form simple LDT RT analysis mixed effects modeeling 
contrasts(fsb$condition) <- contr.treatment(3, base = 3)

fsb1 <- lmer(brtinv ~ condition + 
              (1|participant) + (1|itemN), data = fsb, REML = FALSE)
summary(fsb1)

fsb2 <- lmer(brtinv ~ condition + 
              (1 + condition|participant) + (1|itemN), data = fsb, REML = FALSE)
summary(fsb2)

#form priming RT analysis mixed effects modelling
contrasts(fb$condition) <- contr.treatment(3, base = 3)

fb1 <- lmer(rtinv ~ brtinv + condition * (SelfReading + SelfListening) +
              (1|participant) + (1|itemN), data = fb, REML = FALSE)
summary(fb1)

fb2 <- lmer(rtinv ~ brtinv + condition * (SelfReading + SelfListening) +
              (1 + condition|participant) + (1|itemN), data = fb, REML = FALSE)
summary(fb2)

#form RT 
#ro/monomodal group
#data preparation
fsm <- rename(fsm, brt = rt )
fsm <- select(fsm, - accuracy, - X) #removing unnecessary variables
fpm <- select(fpm, - X, - accuracy) #removing unnecessary variables

fpm <- fpm[ which(fpm$condition == '1'|
                    fpm$condition == '2'|
                    fpm$condition == '3'),]
fsm <- fsm[ which(fsm$condition == '1'|
                    fsm$condition == '2'|
                    fsm$condition == '3'),]

fsm$brtinv <- ( - 1000 / fsm$brt) #RT transforming
fpm$rtinv <- ( - 1000 / fpm$rt)

fsm$condition <- factor(fsm$condition)
fpm$condition <- factor(fpm$condition)

fm <- left_join(fpm, fsm, copy = FALSE) #merge priming and simple LDT RT data 
fm <- left_join(fm, rating, by = "participant") #add self ratings as a variable

#descriptives
describeBy(fpm, fpm$condition)
describeBy(fsm, fsm$condition)

#form simple LDT RT analysis mixed effects modeeling 
contrasts(fsm$condition) <- contr.treatment(3, base = 3)

fsm1 <- lmer(brtinv ~ condition + 
               (1|participant) + (1|itemN), data = fsm, REML = FALSE)
summary(fsm1)

fsm2 <- lmer(brtinv ~ condition + 
               (1 + condition|participant) + (1|itemN), data = fsm, REML = FALSE)
summary(fsm2)

#form priming RT analysis mixed effects modelling
contrasts(fm$condition) <- contr.treatment(3, base = 3)

fm1 <- lmer(rtinv ~ brtinv + condition * (SelfReading + SelfListening) +
              (1|participant) + (1|itemN), data = fm, REML = FALSE)
summary(fm1)

fm2 <- lmer(rtinv ~ brtinv + condition * (SelfReading + SelfListening) +
              (1 + condition|participant) + (1|itemN), data = fm, REML = FALSE)
summary(fm2)

#semantic RT
#rwl/bimodal group
#data preparation
ssb <- rename(ssb, brt = rt, bitemERR = itemERR, bsubjERR = subjERR )
ssb <- select(ssb, - accuracy, - X) #removing unnecessary variables
spb <- select(spb, - X, - accuracy) #removing unnecessary variables

spb <- spb[ which(spb$condition == '1'|
                    spb$condition == '2'), ]
ssb <- ssb[ which(ssb$condition == '1'|
                    ssb$condition == '2'), ]

ssb$brtinv <- ( - 1000 / ssb$brt) #RT transforming
spb$rtinv <- ( - 1000 / spb$rt)

ssb$condition <- factor(ssb$condition)
spb$condition <- factor(spb$condition)

sb <- left_join(spb, ssb, copy = FALSE) #merge priming and simple LDT RT data 
sb <- left_join(sb, rating, by = "participant") #add self ratings as a variable

#descriptives
describeBy(spb, spb$condition)
describeBy(ssb, ssb$condition)

#semantic simple LDT RT analysis mixed effects modeeling 
contrasts(ssb$condition) <- contr.treatment(2, base = 2)

ssb1 <- lmer(brtinv ~ condition + 
               (1|participant) + (1|itemN), data = ssb, REML = FALSE)
summary(ssb1)

ssb2 <- lmer(brtinv ~ condition + 
               (1 + condition|participant) + (1|itemN), data = ssb, REML = FALSE)
summaru(ssb2)

ssb3 <- lmer(brtinv ~ condition + 
               (1 + condition|participant) 
             + (1 + condition|itemN), data = ssb, REML = FALSE)
anova(ssb1, ssb2)

#semantic priming RT analysis mixed effects modelling
contrasts(sb$condition) <- contr.treatment(2, base = 2)

sb1 <- lmer(rtinv ~ brtinv + condition * (SelfReading + SelfListening) +
              (1|participant) + (1|itemN), data = sb, REML = FALSE)
summary(sb1)

sb2 <- lmer(rtinv ~ brtinv + condition * (SelfReading + SelfListening) +
              (1 + condition|participant) + (1|itemN), data = sb, REML = FALSE)
summary(sb2)

sb3 <- lmer(rtinv ~ brtinv + condition * (SelfReading + SelfListening) +
              (1 + condition|participant) + (1 + condition|itemN), data = sb, REML = FALSE)
summary(sb3)

anova(sb1,sb2)

#semantic RT
#ro/monomodal group
#data preparation
ssm <- rename(ssm, brt = rt, bitemERR = itemERR, bsubjERR = subjERR )
ssm <- select(ssm, - accuracy, - X) #removing unnecessary variables
spm <- select(spm, - X, - accuracy) #removing unnecessary variables

spm <- spm[ which(spm$condition == '1'|
                    spm$condition == '2'), ]
ssm <- ssm[ which(ssm$condition == '1'|
                    ssm$condition == '2'), ]

ssm$brtinv <- ( - 1000 / ssm$brt) #RT transforming
spm$rtinv <- ( - 1000 / spm$rt)

ssm$condition <- factor(ssm$condition)
spm$condition <- factor(spm$condition)

sm <- left_join(spm, ssm, copy = FALSE) #merge priming and simple LDT RT data 
sm <- left_join(sm, rating, by = "participant") #add self ratings as a variable

#descriptives
describeBy(spm, spm$condition)
describeBy(ssm, ssm$condition)

#semantic simple LDT RT analysis mixed effects modeeling 
contrasts(ssm$condition) <- contr.treatment(2, base = 2)
ssm1 <- lmer(brtinv ~ condition + 
               (1|participant) + (1|itemN), data = ssm, REML = FALSE)
summary(ssm1)

ssm2 <- lmer(brtinv ~ condition + 
              (1 + condition|participant) + (1|itemN), data = ssm, REML = FALSE)
summary(ssm2)

#semantic priming RT analysis mixed effects modelling
contrasts(sm$condition) <- contr.treatment(2, base = 2)

sm1 <- lmer(rtinv ~ brtinv + condition * (SelfReading + SelfListening) +
              (1|participant) + (1|itemN), data = sm, REML = FALSE)
summary(sm1)

sm2 <- lmer(rtinv ~ brtinv + condition * (SelfReading + SelfListening) +
              (1 + condition|participant) + (1|itemN), data = sm, REML = FALSE)
summary(sm2)

sm3 <- lmer(rtinv ~ brtinv + condition * (SelfReading + SelfListening) +
              (1 + condition|participant) + (1 + condition|itemN), data = sm, REML = FALSE)
summary(sm3)

anova(sm3, sm1,sm2)

#RT group comparison 
fpb <- dplyr::select(fpb, -subjERR, -itemERR)
fpm <- dplyr::select(fpm, -subjERR, -itemERR)

f <- rbind(fpb, fpm)

f1 <- lmer(rtinv ~ group + condition + 
             (1|participant) + (1|itemN), data = f, REML = FALSE)
summary(f1)

spb <- dplyr::select(spb, -subjERR, -itemERR)
spm <- dplyr::select(spm, -subjERR, -itemERR)

s <- merge(x = spb, y = spm, 
           by = c("condition", "rt", "group", "participant", "itemN", "rtinv"), 
           all = TRUE)

s1 <- lmer(rtinv ~ group +  
             (1|participant) + (1|itemN), data = s, REML = FALSE)
summary(s1)
